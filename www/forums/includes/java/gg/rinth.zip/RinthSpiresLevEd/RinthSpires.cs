#region Using
using System;
using System.Collections;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.Threading;
using System.ComponentModel;
using System.Data;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using Microsoft.DirectX.DirectInput;
#endregion

namespace RinthSpires
{
	/// <summary>
	/// Summary description for GameClass.
	/// </summary>
	public class GameClass
	{
    Sprite fontSprite = null;
    Microsoft.DirectX.Direct3D.Font font = null;

    public static string resourceDirectory = "..\\RinthIsland\\Resources\\";
  
    public static ArrayList graphicObjects = new ArrayList(); 
    public static SortedList modelSource = new SortedList();
    public static ArrayList pawns = new ArrayList();
    public static ArrayList fireflies = new ArrayList();
    public static SortedList availablePawns = new SortedList();

    public static SortedList States = new SortedList();
    public static SortedList Alarms = new SortedList();
    public static SortedList Tasks = new SortedList();

    public static Pawn [,,,] tower = new Pawn [10, 50, 200, 5];
    public static ArrayList floaters = new ArrayList();

    public static float Pi = (float)Math.PI;

    public static Pawn skybox = null;
    public static Pawn cursor = null;
    public static Pawn selected = null;
    public static float cursorx = 0;
    public static float cursory = 0;
    public static float cursorspeed = 240.0f;

    public static int towernum = 0;

    public static int amount = 20;
    public static float radius = (50 * amount) / (2 * Pi);
    public static int seebelow = 25;
    public static int seeabove = 9;

    public static float zoom = 0;

    public static float over = -(float)Math.PI / 12;
    public static float centercursorupwards = 50.0f;

    public static float average = 0;

    public static ArrayList GraphicObjects
    {
      get
      {
        return graphicObjects;
      }
    }


		public GameClass()
		{
		}

    #region LoadResources
    public bool LoadResources()
    {
      Directory.SetCurrentDirectory(resourceDirectory); 

      font = new Microsoft.DirectX.Direct3D.Font(MainForm.DirectXDevice, new System.Drawing.Font("Arial", 12));
      fontSprite = new Sprite(MainForm.DirectXDevice);

      AutoGen.LoadModels();     

      cursor = new Pawn("Cube");
      cursor.baseOpacity = 0.5f;

      selected = new Pawn("");

      
      InitLevel1Stuff();

      LoadBlankTower();
          
      return true;
    }
    #endregion


    public void LoadBlankTower()
    {
      for(int t = 0; t < 10; t++)
      {
        for(int x = 0; x < 50; x++)
        {
          for(int y = 0; y < 200; y++)
          {
            for(int z = 0; z < 5; z++)
            {
              tower[t, x, y, z] = null;
            }
          }
        }
      }
    }
   
    public void CalmDelta(ref float delta)
    {
      if(average == 0)
        average = delta;
      else
      {
        if(delta > average * 2)
          delta = average;
        else
          average = (delta + average) / 2;
      }
    }
    
    public void Process()
    {
      // Multiply intended change per second by this
      float delta = ElapsedTime.MoveFactorPerSecond;

      //CalmDelta(ref delta);

      ProcessAlarms(delta);

      if(MainForm.Keyboard.State[Key.W] && Alarms["W"] == null)
      {
        if(MainForm.Toolbox.List_Pawns.SelectedIndex > 0)
          MainForm.Toolbox.List_Pawns.SelectedIndex--;
        else
          MainForm.Toolbox.List_Pawns.SelectedIndex = MainForm.Toolbox.List_Pawns.Items.Count - 1;

        Alarms.Add("W", 0.2f);
      }
      else if(MainForm.Keyboard.State[Key.S] && Alarms["S"] == null)
      {
        if(MainForm.Toolbox.List_Pawns.SelectedIndex < MainForm.Toolbox.List_Pawns.Items.Count - 1)
          MainForm.Toolbox.List_Pawns.SelectedIndex++;
        else
          MainForm.Toolbox.List_Pawns.SelectedIndex = 0;

        Alarms.Add("S", 0.2f);
      }
      else if(MainForm.Keyboard.State[Key.D] &&
        Tasks["cx+"] == null &&
        Tasks["cx-"] == null &&
        Tasks["cy+"] == null &&
        Tasks["cy-"] == null)
      {
        AddToTower((Pawn)selected.Clone(), CursorSlotX(), CursorSlotY());
      }
      else if(MainForm.Keyboard.State[Key.A])
      {
        for(int z = 0; z < 5; z++)
        {
          tower[towernum, CursorSlotX(), CursorSlotY(), z] = null;
        }
      }
      else if(MainForm.Keyboard.State[Key.Space] && Alarms["s"] == null &&
        Tasks["cx+"] == null &&
        Tasks["cx-"] == null &&
        Tasks["cy+"] == null &&
        Tasks["cy-"] == null)
      {
        for(int x = 0; x < 50; x++)
        {
          tower[towernum, x, CursorSlotY(), 0] = (Pawn)selected.Clone();

          for(int z = 1; z < 5; z++)
          {
            tower[towernum, x, CursorSlotY(), z] = null;
          }
        }
        
      }

      if(MainForm.Keyboard.State[Key.Q] && Alarms["Q"] == null)
      {
        for(int z = 0; z < 5; z++)
        {
          if(tower[towernum, CursorSlotX(), CursorSlotY(), z] != null)
          {
            tower[towernum, CursorSlotX(), CursorSlotY(), z].rinth_rotate++;

            if(tower[towernum, CursorSlotX(), CursorSlotY(), z].rinth_rotate > 3)
              tower[towernum, CursorSlotX(), CursorSlotY(), z].rinth_rotate = 0;
          }
        }

        Alarms.Add("Q", 0.2f);
      }
      else if(MainForm.Keyboard.State[Key.E] && Alarms["E"] == null)
      {
        for(int z = 0; z < 5; z++)
        {
          if(tower[towernum, CursorSlotX(), CursorSlotY(), z] != null)
          {
            tower[towernum, CursorSlotX(), CursorSlotY(), z].rinth_rotate--;
            
            if(tower[towernum, CursorSlotX(), CursorSlotY(), z].rinth_rotate < 0)
              tower[towernum, CursorSlotX(), CursorSlotY(), z].rinth_rotate = 3;
          }
        }

        Alarms.Add("E", 0.2f);
      }


      if(MainForm.Keyboard.State[Key.NumPad8])
        zoom -= 40.0f * delta;

      if(MainForm.Keyboard.State[Key.NumPad2])
        zoom += 40.0f * delta;

      if(MainForm.Keyboard.State[Key.NumPad4])
        over -= Pi / 4 * delta;

      if(MainForm.Keyboard.State[Key.NumPad6])
        over += Pi / 4 * delta;

    
      if(MainForm.Keyboard.State[Key.PageUp] && Alarms["TowerShift"] == null)
      {
        Alarms.Add("TowerShift", 0.2f);

        for(int y = 199; y > -1; y--)
        {
          for(int x = 0; x < 50; x++)
          {
            for(int z = 0; z < 5; z++)
            {
              if(y > 0)
                tower[towernum, x, y, z] = tower[towernum, x, y - 1, z];
              else
                tower[towernum, x, y, z] = null;
            }
          }
        }
      }

      if(MainForm.Keyboard.State[Key.PageDown] && Alarms["TowerShift"] == null)
      {
        Alarms.Add("TowerShift", 0.2f);

        for(int y = 0; y < 200; y++)
        {
          for(int x = 0; x < 50; x++)
          {
            for(int z = 0; z < 5; z++)
            {
              if(y < 199)
                tower[towernum, x, y, z] = tower[towernum, x, y + 1, z];
              else
                tower[towernum, x, y, z] = null;
            }
          }
        }
      }


      //// Handle cursor commands

      if(MainForm.Keyboard.State[Key.Right] && Tasks["cx+"] == null && Tasks["cx-"] == null)
        Tasks.Add("cx+", new Task(cursorx + 20.0f, cursorspeed, 50 * 20));

      if(MainForm.Keyboard.State[Key.Left] && Tasks["cx+"] == null && Tasks["cx-"] == null)
        Tasks.Add("cx-", new Task(cursorx - 20.0f, -cursorspeed, 50 * 20));

      if(MainForm.Keyboard.State[Key.Up] && Tasks["cy+"] == null && Tasks["cy-"] == null && CursorSlotY() < 199)
        Tasks.Add("cy+", new Task(cursory + 20.0f, cursorspeed, 0.0f));

      if(MainForm.Keyboard.State[Key.Down] && Tasks["cy+"] == null && Tasks["cy-"] == null && CursorSlotY() > 0)
        Tasks.Add("cy-", new Task(cursory - 20.0f, -cursorspeed, 0.0f));

      //// Process cursor movement
      
      if(Tasks["cx+"] != null)
        if(((Task)Tasks["cx+"]).Progress(ref cursorx, delta)) 
          Tasks.Remove("cx+");

      if(Tasks["cx-"] != null)
        if(((Task)Tasks["cx-"]).Progress(ref cursorx, delta)) 
          Tasks.Remove("cx-");

      if(Tasks["cy+"] != null)
        if(((Task)Tasks["cy+"]).Progress(ref cursory, delta)) 
          Tasks.Remove("cy+");

      if(Tasks["cy-"] != null)
        if(((Task)Tasks["cy-"]).Progress(ref cursory, delta)) 
          Tasks.Remove("cy-");

      //// Some wrap handling

      Util.Wrap(ref cursorx, 20 * 50);
      Util.Wrap(ref over, 2 * Pi);

      ProgrammaticAnimations(delta);

      for(int x = 0; x < 50; x++)
      {
        for(int y = 0; y < 200; y++)
        {
          for(int z = 0; z < 5; z++)
          {
            if(tower[towernum, x, y, z] != null)
            {
              string result = tower[towernum, x, y, z].Process(delta);

              if(result != "")
              {
                if(result == "die")
                {
                  tower[towernum, x, y, z] = null;
                }
                else if(result == "cx+")
                {
                  if(!AddToTower((Pawn)tower[towernum, x, y, z].Clone(), x + 1, y))
                    Console.WriteLine("Tower slot full!");
                  else
                    tower[towernum, x, y, z] = null;
                }
                else if(result == "cx-")
                {
                  if(!AddToTower((Pawn)tower[towernum, x, y, z].Clone(), x - 1, y))
                    Console.WriteLine("Tower slot full!");
                  else
                    tower[towernum, x, y, z] = null;
                }
                else if(result == "cy+")
                {
                  if(!AddToTower((Pawn)tower[towernum, x, y, z].Clone(), x, y + 1))
                    Console.WriteLine("Tower slot full!");
                  else
                    tower[towernum, x, y, z] = null;
                }
                else if(result == "cy-")
                {
                  if(!AddToTower((Pawn)tower[towernum, x, y, z].Clone(), x, y - 1))
                    Console.WriteLine("Tower slot full!");
                  else
                    tower[towernum, x, y, z] = null;
                }          
              }
            }
          }
        }
      }
    }

    static float windmill = 0.0f;
    static float windrot = 0.0f;
    public void ProgrammaticAnimations(float delta)
    {
      windrot += (Pi / 16) * delta;
      Util.Wrap(ref windrot, 2 * Pi);

      windmill += (float)Math.Sin(windrot) / 100;
      Util.Wrap(ref windmill, 2 * Pi);

      

      waterangle += (Pi / 4) * delta;
      Util.Wrap(ref waterangle, 2 * Pi);


      //waterfall[0].M31 += 0.3f * delta;
      waterfall[0].M31 += 0.6f * delta;
      Util.Wrap(ref waterfall[0].M31, 1.0f);

      //waterfall[1].M31 += 0.13f * delta;
      waterfall[1].M31 += 0.3f * delta;
      Util.Wrap(ref waterfall[1].M31, 1.0f);

      //waterfall[2].M31 += 0.7f * delta;
      waterfall[2].M31 += 0.8f * delta;
      Util.Wrap(ref waterfall[2].M31, 1.0f);
    }

    public void ProcessAlarms(float delta)
    {
      float f = 0.0f;

      for(int i = 0; i < Alarms.Count; i++)
      {
        f = (float)Alarms.GetByIndex(i);

        f -= delta;

        if(f <= 0.0f)
        {
          ProcessAlarm((string)Alarms.GetKey(i));
          Alarms.RemoveAt(i);
          
          if(i > 0)
            i--;
        }
        else
          Alarms[(string)Alarms.GetKey(i)] = f;
      }    
    }

    public void ProcessAlarm(string alarm)
    {


    }

    #region Render
    public void Render()
    {
      if(MainForm.DirectXDevice == null || MainForm.DirectXDevice.Disposed) return;

      try
      {
        MainForm.DirectXDevice.Clear(ClearFlags.Target | ClearFlags.ZBuffer, Color.Black, 1, 0);
        MainForm.DirectXDevice.BeginScene();
        MainForm.EnableAlphaBlending();
        //RenderOnScreen(backgroundTexture);             

        switch(towernum)
        {
          case 0: RenderLevel1PreObjects(); break;
          case 1: RenderLevel2PreObjects(); break;
          case 2: RenderLevel3PreObjects(); break;
          case 3: RenderLevel4PreObjects(); break;
          case 4: RenderLevel5PreObjects(); break;
        }
        

        MainForm.device.RenderState.Lighting = true;
        MainForm.DirectXDevice.RenderState.ZBufferEnable = true;

        MainForm.device.Transform.Projection = 
          Matrix.PerspectiveFovLH(MainForm.fieldOfView, MainForm.aspectRatio, MainForm.nearPlane, 1000);

        foreach(Pawn pawn in floaters)
        {
          pawn.Render(                       
            Matrix.RotationX(over) 
            );
        }    

        for(int x = 0; x < 50; x++)
        {
          for(int y = 0; y < 200; y++)
          {
            if(cursory / 20 >= y - seeabove && cursory / 20 <= y + seebelow)
            {
              for(int z = 0; z < 5; z++)
              {
                if(tower[towernum, x, y, z] != null)
                {
                  if(tower[towernum, x, y, z].baseModel == "Windmill")
                  {
                    float millmod = x * 50 + y + windmill;
                    Util.Wrap(ref millmod, Pi * 2);
                    tower[towernum, x, y, z].matrix = Matrix.RotationZ(millmod);
                  }

                  if(tower[towernum, x, y, z].rinth_rotate == 0)
                  {
                    tower[towernum, x, y, z].Render(
                      Matrix.RotationY(Pi) *
                      Matrix.Translation(0, y * 20 - cursory + centercursorupwards, radius - 10) *     
                      Matrix.RotationY( (((float)x / 50) * 2 * Pi) + (((float)((cursorx / 20) / 50) * 2 * Pi)) ) *        
                      Matrix.Translation(0, 0, zoom) *
                      Matrix.RotationX(over)
                      );
                  }
                  else
                  {
                    tower[towernum, x, y, z].Render(
                      Matrix.RotationZ(tower[towernum, x, y, z].rinth_rotate * (Pi / 2)) *
                      Matrix.RotationY(Pi) *
                      Matrix.Translation(0, y * 20 - cursory + centercursorupwards, radius - 10) *     
                      Matrix.RotationY( (((float)x / 50) * 2 * Pi) + (((float)((cursorx / 20) / 50) * 2 * Pi)) ) *        
                      Matrix.Translation(0, 0, zoom) *
                      Matrix.RotationX(over)
                      );
                  }
                }
              }
            }
          }
        }

        switch(towernum)
        {
          case 1: RenderLevel2PostObjects(); break;
          case 3: RenderLevel4PostObjects(); break;
        }

        if(cursor != null && false)
        {
          cursor.Render(             
            Matrix.Translation(0, centercursorupwards, -radius + 10) *
            Matrix.RotationX(over) 
            );
        }

        MainForm.DirectXDevice.RenderState.ZBufferEnable = false;
        if(selected != null)
        {
          selected.Render(
            Matrix.RotationX(-Pi / 8) *
            Matrix.Translation(-83, -53, -240)          
            );
        }
        MainForm.DirectXDevice.RenderState.ZBufferEnable = true;



        RenderText(10, 10, ElapsedTime.FramesPerSecond.ToString());

        //RenderText(10, 90, ((int)((AnimatedPawn)pawns[0]).currentFrame).ToString());
        

        MainForm.DirectXDevice.RenderState.ZBufferEnable = false;
      }
      catch(Exception ex)
      {
        Console.WriteLine("!!!!! Render: " + ex.ToString());
        MainForm.bailout = true;
      }
      finally
      {

        MainForm.DirectXDevice.EndScene();
        MainForm.DirectXDevice.Present();
      }
    }
    #endregion

    static public void LoadLevel(int l)
    {
      cursory = 0;

      towernum = l;

      switch(l)
      {
        case 0: InitLevel1Stuff(); break;
        case 1: InitLevel2Stuff(); break;
        case 2: InitLevel3Stuff(); break;
        case 3: InitLevel4Stuff(); break;
        case 4: InitLevel5Stuff(); break;
      }
    }

    public static float skyscale = 500.0f;
    public static float vertskyscale = 500.0f;
    public static float skyslow = 1.5f;
    public static float skydrop = 1500.0f;

    public static Pawn horizon = null;
    public static Pawn [] water = new Pawn [8];
    public static float waterangle = 0;

    public static Matrix [] waterfall = new Matrix [3];

    #region Level Inits
    private static void InitLevel1Stuff()
    {
      skyscale = 500.0f;
      vertskyscale = 500.0f;
      skyslow = 1.5f;
      skydrop = 1500.0f;

      skybox = new Pawn("Sky_Rainbow");

      water[0] = new Pawn("Water");
      water[0].baseOpacity = 0.3f;

      water[1] = new Pawn("Water");
      water[1].baseOpacity = 0.4f;

      water[2] = new Pawn("Water");
      water[2].baseOpacity = 0.5f;

      water[3] = new Pawn("Water");

      horizon = new Pawn("Horizon");
    }

    private static void InitLevel2Stuff()
    {
      skyscale = 1.0f;
      vertskyscale = 1.0f;
      skyslow = 1.0f;
      skydrop = 1500.0f;

      skybox = new Pawn("Sky_Abyss");

      horizon = new Pawn("Spotlight");

      water[0] = new Pawn("Mist");
    }

    private static void InitLevel3Stuff()
    {
      skyscale = 500.0f;
      vertskyscale = 500.0f;
      skyslow = 1.5f;
      skydrop = 1500.0f;

      skybox = new Pawn("Sky_Rainbow");

      water[0] = new Pawn("Patch");
      water[1] = new Pawn("Mist");

      water[2] = new Pawn("Falls"); water[2].baseOpacity = 0.3f;
      water[3] = new Pawn("Falls"); water[3].baseOpacity = 0.5f;
      water[4] = new Pawn("Falls");

      waterfall[0] = Matrix.Transformation2D(new Vector2(0, 0), 0, new Vector2(1.0f, 1.0f), new Vector2(0.0f, 0.0f), (Pi / 2), Vector2.Empty);
      waterfall[1] = Matrix.Transformation2D(new Vector2(0, 0), 0, new Vector2(1.0f, 1.0f), new Vector2(0.0f, 0.0f), (Pi / 2), Vector2.Empty);
      waterfall[2] = Matrix.Transformation2D(new Vector2(0, 0), 0, new Vector2(1.0f, 1.0f), new Vector2(0.0f, 0.0f), (Pi / 2), Vector2.Empty);
    }

    private static void InitLevel4Stuff()
    {
      skyscale = 500.0f;
      vertskyscale = 1400.0f;
      skyslow = 0.1f;
      skydrop = 6000.0f;

      skybox = new Pawn("Sky_Dusk");

      water[0] = new Pawn("Trunk");
      water[1] = new Pawn("Tree");

      horizon = new Pawn("Sky_Trees");
    }

    private static void InitLevel5Stuff()
    {
      skyscale = 500.0f;
      vertskyscale = 500.0f;
      skyslow = 1.5f;
      skydrop = 4500.0f;

      skybox = new Pawn("Mountains");
      water[0] = new Pawn("Mountain");
    }
    #endregion

    #region Level Renders
    private void RenderLevel1PreObjects()
    {
      MainForm.device.RenderState.Lighting = false;
      MainForm.DirectXDevice.RenderState.ZBufferEnable = true;    
        
      MainForm.device.Transform.Projection = 
        Matrix.PerspectiveFovLH(MainForm.fieldOfView, MainForm.aspectRatio, MainForm.nearPlane, 50000);

      if(skybox != null)
      {
        skybox.Render(                 
          Matrix.Scaling(skyscale, vertskyscale, skyscale) *
          Matrix.Translation(0, centercursorupwards - 50 - (cursory * skyslow) - skydrop, 0) *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi)) *        
          Matrix.RotationX(over)
          );
      }

      MainForm.device.RenderState.Lighting = true;
      MainForm.DirectXDevice.RenderState.ZBufferEnable = false;



      float [] circlex = new float [4];
      float [] circlez = new float [4];

      float sinmag = 50.0f;
      float cosmag = 100.0f;

      circlex[0] = (float)Math.Sin(waterangle) * sinmag;
      circlez[0] = (float)Math.Cos(waterangle) * cosmag;

      circlex[1] = (float)Math.Sin(waterangle - (Pi / 2)) * -sinmag;
      circlez[1] = (float)Math.Cos(waterangle - (Pi / 2)) * -cosmag;

      circlex[2] = (float)Math.Sin(waterangle - Pi) * -sinmag;
      circlez[2] = (float)Math.Cos(waterangle - Pi) * cosmag;

      circlex[3] = (float)Math.Sin(waterangle - (2 * Pi / 2)) * sinmag;
      circlez[3] = (float)Math.Cos(waterangle - (2 * Pi / 2)) * -cosmag;

      for(int w = 3; w >= 0; w--)
      {
        if(water[w] != null)
        {
          //Color [] lighting = {Color.FromArgb(100, 100, 100), Color.FromArgb(250, 250, 250), Color.FromArgb(250, 250, 250)};
          Color [] lighting = {Color.FromArgb(250, 250, 250), Color.FromArgb(0, 0, 0), Color.FromArgb(250, 250, 250)};


          water[w].Render(
            Matrix.Scaling(20.0f, 1.0f, 20.0f) *
            Matrix.Translation(circlex[w], -cursory - (2 * w) - 800, circlez[w]) *     
            Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi) + (Pi / 2 * w)) *        
            Matrix.RotationX(over),
            lighting
            );
        }
      }

      if(horizon != null)
      {
        horizon.Render(
          Matrix.Scaling(17.0f, 1.0f, 17.0f) *
          Matrix.Translation(0, -cursory - 785, 0) *    
          Matrix.RotationY((float)((cursorx / 20) / 50) * 2 * Pi) *        
          Matrix.RotationX(over)
          );
      }        
    }

    private void RenderLevel2PreObjects()
    {
      MainForm.device.RenderState.Lighting = false;
      MainForm.DirectXDevice.RenderState.ZBufferEnable = false;    
        
      MainForm.device.Transform.Projection = 
        Matrix.PerspectiveFovLH(MainForm.fieldOfView, MainForm.aspectRatio, MainForm.nearPlane, 50000);

      if(skybox != null)
      {
        skybox.Render(                 
          Matrix.Scaling(skyscale, vertskyscale, skyscale) *
          Matrix.Translation(0, centercursorupwards - 50 - (cursory * skyslow) + 2000, 0) *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi)) *        
          Matrix.RotationX(over)
          );
      } 
    }

    static Pawn lode = null;
    private void RenderLevel2PostObjects()
    {
      MainForm.device.RenderState.Lighting = true;

      /*
      if(lode != null)
      {
         lode.Render(                 
           Matrix.RotationY((float)((cursorx / 20) / 50) * 2 * Pi) *    `
           Matrix.RotationX(over)
            );

        lode.Render(Matrix.Translation(0.0f, 120.0f, 0.0f) *   
          Matrix.RotationY((float)((cursorx / 20) / 50) * 2 * Pi) *    
          Matrix.RotationX(over)
          );

      }
      else
        lode = new Pawn("Lode");
        
      */

      MainForm.device.RenderState.Lighting = false;

      /*
      MainForm.DirectXDevice.RenderState.ZBufferEnable = true;   
 
      if(water[0] != null)
      {
        water[0].Render(                 
          Matrix.Scaling(13.0f, 30.0f, 1.0f) *
          Matrix.RotationX(over)
          );
      } 
      */

      MainForm.DirectXDevice.RenderState.ZBufferEnable = false;  

      if(horizon != null)
      {
        horizon.Render(
          Matrix.Scaling(17.0f, 19.0f, 18.0f) *
          Matrix.Translation(0, 0, 0)      
          );
      } 
    }



    private void RenderLevel3PreObjects()
    {
      /*
      MainForm.device.RenderState.Lighting = false;
      MainForm.DirectXDevice.RenderState.ZBufferEnable = true;    
        
      MainForm.device.Transform.Projection = 
        Matrix.PerspectiveFovLH(MainForm.fieldOfView, MainForm.aspectRatio, MainForm.nearPlane, 50000);

      if(skybox != null)
      {
        skybox.Render(                 
          Matrix.Scaling(skyscale, vertskyscale, skyscale) *
          Matrix.Translation(0, centercursorupwards - 50 - (cursory * skyslow) - skydrop, 0) *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi)) *        
          Matrix.RotationX(over)
          );
      }
      */

      MainForm.device.RenderState.Lighting = true;
      MainForm.DirectXDevice.RenderState.ZBufferEnable = true;

      if(water[0] != null)
      {
        water[0].Render(
          Matrix.Scaling(3.0f, 3.5f, 3.0f) *
          Matrix.Translation(0, -cursory - 150, 0) *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi)) *        
          Matrix.RotationX(over)
          ); 
      }

      Matrix fallsdrop = Matrix.Translation(0, (-cursory / 10) - 450, 0);

      if(water[4] != null)
      {
        MainForm.DirectXDevice.SetTextureStageState(0, TextureStageStates.TextureTransform, (int)TextureTransform.Count2 ); 

        MainForm.DirectXDevice.Transform.Texture0 = waterfall[2];

        water[4].Render(
          Matrix.Scaling(3.8f, 3.5f, 3.8f) *
          fallsdrop *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi)) *        
          Matrix.RotationX(over)
          ); 

        MainForm.DirectXDevice.SetTextureStageState( 0, TextureStageStates.TextureTransform, (int)TextureTransform.Disable ); 
      }

      if(water[3] != null)
      {
        MainForm.DirectXDevice.SetTextureStageState(0, TextureStageStates.TextureTransform, (int)TextureTransform.Count2 ); 
        MainForm.DirectXDevice.Transform.Texture0 = waterfall[1];

        water[3].Render(
          Matrix.Scaling(3.6f, 3.5f, 3.6f) *
          fallsdrop *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi)) *        
          Matrix.RotationX(over)
          ); 

        MainForm.DirectXDevice.SetTextureStageState( 0, TextureStageStates.TextureTransform, (int)TextureTransform.Disable ); 
      }

      if(water[2] != null)
      {
        
        MainForm.DirectXDevice.SetTextureStageState(0, TextureStageStates.TextureTransform, (int)TextureTransform.Count2 ); 
        MainForm.DirectXDevice.Transform.Texture0 = waterfall[0];

        water[2].Render(
          Matrix.Scaling(3.5f, 3.5f, 3.5f) *
          fallsdrop *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi)) *        
          Matrix.RotationX(over)
          ); 

        MainForm.DirectXDevice.SetTextureStageState( 0, TextureStageStates.TextureTransform, (int)TextureTransform.Disable ); 
      }




      MainForm.device.RenderState.Lighting = false;

      if(water[1] != null)
      {
        water[1].Render(
          Matrix.Scaling(3.0f, 3.0f, 3.0f) *
          Matrix.Translation(0, -cursory - 150, 0) *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi)) *        
          Matrix.RotationX(over)
          ); 
      }

      

      if(horizon != null)
      {
        horizon.Render(
          Matrix.Scaling(17.0f, 1.0f, 17.0f) *
          Matrix.Translation(0, -cursory - 785, 0) *    
          Matrix.RotationY((float)((cursorx / 20) / 50) * 2 * Pi) *        
          Matrix.RotationX(over)
          );
      } 
    }

    static float treeoffset = 0.0f;
    private void RenderLevel4PreObjects()
    {
      MainForm.device.RenderState.Lighting = false;
      MainForm.DirectXDevice.RenderState.ZBufferEnable = false;    
        
      MainForm.device.Transform.Projection = 
        Matrix.PerspectiveFovLH(MainForm.fieldOfView, MainForm.aspectRatio, MainForm.nearPlane, 50000);

      if(skybox != null)
      {
        skybox.Render(                 
          Matrix.Scaling(skyscale, vertskyscale, skyscale) *
          Matrix.Translation(0, centercursorupwards - 50 - (cursory * skyslow) - skydrop, 0) *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi)) *        
          Matrix.RotationX(over)
          );
      } 

      MainForm.device.RenderState.Lighting = false;
      MainForm.DirectXDevice.RenderState.ZBufferEnable = true;

      if(horizon != null)
      {
        horizon.Render(                 
          Matrix.Scaling(60.0f, 40.0f, 60.0f) *
          Matrix.Translation(0, centercursorupwards - 50 - (cursory * skyslow * 0.5f) - 900, 0) *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2.0f * Pi)) *        
          Matrix.RotationX(over)
          );
      } 

      if(horizon != null)
      {
        horizon.Render(                 
          Matrix.Scaling(50.0f, 40.0f, 50.0f) *
          Matrix.Translation(0, centercursorupwards - 50 - (cursory * skyslow * 0.5f) - 900, 0) *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2.0f * Pi) + ((Pi / 4.0f))) *        
          Matrix.RotationX(over)
          );
      } 

      if(horizon != null)
      {
        horizon.Render(                 
          Matrix.Scaling(40.0f, 40.0f, 40.0f) *
          Matrix.Translation(0, centercursorupwards - 50 - (cursory * skyslow * 0.5f) - 900, 0) *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2.0f * Pi) + ((Pi / 4.0f) * 2.0f)) *        
          Matrix.RotationX(over)
          );
      } 

      if(horizon != null)
      {
        horizon.Render(                 
          Matrix.Scaling(30.0f, 40.0f, 30.0f) *
          Matrix.Translation(0, centercursorupwards - 50 - (cursory * skyslow * 0.5f) - 900, 0) *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2.0f * Pi) + ((Pi / 4.0f) * 3.0f)) *        
          Matrix.RotationX(over)
          );
      } 

      MainForm.device.RenderState.Lighting = true;

      MainForm.device.Transform.Projection = 
        Matrix.PerspectiveFovLH(MainForm.fieldOfView, MainForm.aspectRatio, MainForm.nearPlane, 1000);

      treeoffset = (int)(cursory / 240) * 240;

      if(water[0] != null && treeoffset == 0)
      {
        water[0].Render(
          //Matrix.Scaling(1.0f, 1.0f, 1.0f) *   
          Matrix.Translation(0, -cursory - 150, 0) *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi)) *        
          Matrix.RotationX(over)
          ); 
      }

      if(water[1] != null)
      {
        water[1].Render(
          Matrix.Scaling(0.75f, 0.75f, 0.75f) *
          Matrix.Translation(0, -cursory - 250 + treeoffset, 0) *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi)) *        
          Matrix.RotationX(over)
          ); 

        water[1].Render(
          Matrix.Scaling(0.75f, 0.75f, 0.75f) *
          Matrix.Translation(0, -cursory - 250 + 240 + treeoffset, 0) *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi)) *        
          Matrix.RotationX(over)
          ); 

        water[1].Render(
          Matrix.Scaling(0.75f, 0.75f, 0.75f) *
          Matrix.Translation(0, -cursory - 250 + 480 + treeoffset, 0) *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi)) *        
          Matrix.RotationX(over)
          ); 
      }

      /*
      for(int i = 0; i < 10; i++)
      {
        float x = (float)Math.Cos(2 * Pi / 10 * i) * 1000;
        float z = (float)Math.Sin(2 * Pi / 10 * i) * 1000;

        if(water[0] != null)
        {
          water[0].Render(
            Matrix.Scaling(0.75f, 0.75f, 0.75f) *
            Matrix.Translation(x, -cursory - 150, z) *     
            Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi)) *        
            Matrix.RotationX(over)
            ); 
        }

        if(water[1] != null)
        {
          water[1].Render(
            Matrix.Scaling(0.75f, 0.75f, 0.75f) *
            Matrix.Translation(x, -cursory - 150, z) *     
            Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi)) *        
            Matrix.RotationX(over)
            ); 
        }
      }
      */
    }

    private void RenderLevel4PostObjects()
    {

      /*
      MainForm.device.RenderState.Lighting = false;
      MainForm.DirectXDevice.RenderState.ZBufferEnable = false;  

      if(horizon != null)
      {
        horizon.Render(
          Matrix.Scaling(17.0f, 19.0f, 18.0f) *
          Matrix.Translation(0, 0, 0)      
          );
      } 
      */
    }

    private void RenderLevel5PreObjects()
    {
      MainForm.device.RenderState.Lighting = false;
      MainForm.DirectXDevice.RenderState.ZBufferEnable = false;

      MainForm.device.Transform.Projection = 
        Matrix.PerspectiveFovLH(MainForm.fieldOfView, MainForm.aspectRatio, MainForm.nearPlane, 50000);


      if(skybox != null)
      {
        skybox.Render(                 
          Matrix.Scaling(skyscale, vertskyscale, skyscale) *
          Matrix.Translation(0, centercursorupwards - 50 - (cursory * skyslow) - skydrop, 0) *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi)) *        
          Matrix.RotationX(over)
          );
      }

      MainForm.DirectXDevice.RenderState.ZBufferEnable = true;
  

      if(water[0] != null)
      {
        water[0].Render(                 
          Matrix.Scaling(60.0f, 40.0f, 60.0f) *
          Matrix.Translation(0, centercursorupwards - 50 - (cursory * skyslow * 0.2f) - 200, 0) *     
          Matrix.RotationY(((float)((cursorx / 20) / 50) * 2 * Pi)) *        
          Matrix.RotationX(over)
          );
      }


      MainForm.device.Transform.Projection = 
        Matrix.PerspectiveFovLH(MainForm.fieldOfView, MainForm.aspectRatio, MainForm.nearPlane, 1000);
    }
    #endregion

    #region RenderText
    public void RenderText(int x, int y, string message)
    {
      fontSprite.Begin(SpriteFlags.AlphaBlend);
      font.DrawText(fontSprite, message, new Point(x, y), Color.White);
      fontSprite.End();  
    }
    #endregion

    #region RenderOnScreen
    public void RenderOnScreen(Texture texture)
    {
      /*
      CustomVertex.TransformedTextured[] screenVerts = new CustomVertex.TransformedTextured[4];

      screenVerts[0] = new CustomVertex.TransformedTextured(0, 0, 0, 1, 0, 0);
      screenVerts[1] = new CustomVertex.TransformedTextured(this.ClientSize.Width, 0, 0, 1, 1, 0);
      screenVerts[2] = new CustomVertex.TransformedTextured(this.ClientSize.Width, this.ClientSize.Height, 0, 1, 1, 1);
      screenVerts[3] = new CustomVertex.TransformedTextured(0, this.ClientSize.Height, 0, 1, 0, 1);

      MainForm.DirectXDevice.RenderState.ZBufferEnable = false;
      MainForm.DirectXDevice.SetTexture(0, texture);
      MainForm.DirectXDevice.VertexFormat = CustomVertex.TransformedTextured.Format;
      MainForm.DirectXDevice.DrawUserPrimitives(PrimitiveType.TriangleFan, 2, screenVerts);
      MainForm.DirectXDevice.RenderState.ZBufferEnable = true;
      */
    }
    #endregion

    bool AddToTower(Pawn pawn, int x, int y)
    {
      bool added = false;

      for(int z = 0; z < 5; z++)
      {
        if(tower[towernum, x, y, z] != null)
        {
          if(pawn.baseModel == tower[towernum, x, y, z].baseModel)
            return true;
        }
      }

      for(int z = 0; z < 5; z++)
      {
        if(tower[towernum, x, y, z] == null)
        {
          tower[towernum, x, y, z] = (Pawn)pawn.Clone();
          added = true;
          break;
        }
      }
      
      return added;
    }

    int CursorSlotX()
    {
      float afterwrap = (-cursorx / 20) + 25;

      Util.WrapExclusive(ref afterwrap, 50);

      return (int)afterwrap;
    }
      
    int CursorSlotY()
    {
      return (int)(cursory / 20);
    }

    #region MainForm Triggers
    public void OnResetDevice()
    {
      foreach (IGraphicObject gob in graphicObjects)
        gob.OnResetDevice();
    }

    public void OnLostDevice()
    {
      foreach (IGraphicObject gob in graphicObjects)
        gob.OnLostDevice();
    }

    public void OnDisposingDevice()
    {
      foreach (IGraphicObject gob in graphicObjects)
        gob.Dispose();
    }
    #endregion

    public static void SaveOut()
    {
      StreamWriter fileout = new StreamWriter(new FileStream(".\\RinthIsland.dat", FileMode.Create, FileAccess.Write));

      for(int i = 0; i < availablePawns.Count; i++)
      {
        Pawn pawn = (Pawn)((Pawn)availablePawns.GetByIndex(i)).Clone();
        fileout.WriteLine("TowerPawn");
        fileout.WriteLine(pawn.baseModel);
        fileout.WriteLine(pawn.width.ToString());
        fileout.WriteLine(pawn.height.ToString());
        fileout.WriteLine(pawn.className);

        foreach(string modelname in pawn.modelNames)
          fileout.WriteLine(modelname);

        fileout.WriteLine("Animations");

        foreach(string animation in pawn.animations.GetKeyList())
          fileout.WriteLine(animation);

        fileout.WriteLine("Done");
      }

      fileout.WriteLine("Towers");

      for(int t = 0; t < 10; t++)
      {
        for(int x = 0; x < 50; x++)
        {
          for(int y = 0; y < 200; y++)
          {
            for(int z = 0; z < 5; z++)
            {
              if(tower[t, x, y, z] == null)
              {
                fileout.WriteLine("-1");
              }
              else
              {
                fileout.WriteLine(IndexOfPawn(tower[t, x, y, z]).ToString());
                fileout.WriteLine(tower[t, x, y, z].rinth_rotate.ToString());
              }
            }
          }
        }
      }

      fileout.Close();
    }

    public static void LoadIn()
    {
      StreamReader filein = new StreamReader(".\\RinthIsland.dat");

      string read = "";

      while(filein.ReadLine() == "TowerPawn")
      {
        Pawn toadd = new Pawn();

        toadd.baseModel = filein.ReadLine();
        toadd.width = Convert.ToInt32(filein.ReadLine());
        toadd.height = Convert.ToInt32(filein.ReadLine());
        toadd.className = filein.ReadLine();

        while((read = filein.ReadLine()) != "Animations")
          toadd.modelNames.Add(read);

        while((read = filein.ReadLine()) != "Done")
          toadd.animations.Add(read, new ArrayList());

        availablePawns.Add(toadd.baseModel, toadd.Clone());
      }

      for(int t = 0; t < 10; t++)
      {
        for(int x = 0; x < 50; x++)
        {
          for(int y = 0; y < 200; y++)
          {
            for(int z = 0; z < 5; z++)
            {
              if((read = filein.ReadLine()) == "-1")
                tower[t, x, y, z] = null;
              else
              {
                
                tower[t, x, y, z] = (Pawn)((Pawn)availablePawns.GetByIndex(Convert.ToInt32(read))).Clone();
                tower[t, x, y, z].rinth_rotate = Convert.ToInt32(filein.ReadLine());
              }
            }
          }
        }
      }    

      MainForm.Toolbox.RefreshPawnList();

      filein.Close();
    }

    public static int IndexOfPawn(Pawn pawn)
    {
      for(int i = 0; i < availablePawns.Count; i++)
      {
        if(pawn.baseModel == ((Pawn)availablePawns.GetByIndex(i)).baseModel)
          return i;
      }

      return -1;
    }

	}

  public class Mountain
  {
    public float x;
    public float y;
    public float size;

    public Mountain()
    {}
  }

  public class Firefly
  {
    public Vector3 movement;

  }
}
