#region Using directives
using System;
using System.Collections;
using System.Text;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using VertexFormats = Microsoft.DirectX.Direct3D.VertexFormats;
using DXHelp = Microsoft.DirectX.DXHelp;
#endregion

namespace RinthSpires
{
  /// <summary>
  /// TangentVertex, extracted from Abi.Graphic engine for NormalMapCompressor.
  /// More information can be found at:
  /// http://exdream.dyn.ee/blog/PermaLink.aspx?guid=cd2c85b3-13e6-48cd-953e-f7e3bb79fbc5
  /// <para/>
  /// Tangent vertex format for shader vertex format used all over the place.
  /// DirectX9 does not provide this crazy format ^^ It contains:
  /// Position, Normal vector, texture coords, tangent vector.
  /// </summary>
  public struct TangentVertex
  {
    #region Variables
    /// <summary>
    /// Position
    /// </summary>
    public Vector3 pos;
    /// <summary>
    /// Texture coordinates
    /// </summary>
    public float u, v;
    /// <summary>
    /// Normal
    /// </summary>
    public Vector3 normal;
    /// <summary>
    /// Tangent
    /// </summary>
    public Vector3 tangent;

    /// <summary>
    /// Stride size
    /// </summary>
    public static int StrideSize
    {
      get
      {
        return DXHelp.GetTypeSize(typeof(TangentVertex));
      } // get
    } // StrideSize
    #endregion

    #region Constructor
    /// <summary>
    /// Create tangent vertex
    /// </summary>
    public TangentVertex(
      Vector3 setPos,
      float setU, float setV,
      Vector3 setNormal,
      Vector3 setTangent)
    {
      pos = setPos;
      u = setU;
      v = setV;
      normal = setNormal;
      tangent = setTangent;
    } // TangentVertex(setPos, setU, setV)
    #endregion

    #region To string
    /// <summary>
    /// To string
    /// </summary>
    public override string ToString()
    {
      return "TangentVertex(pos=" + pos + ", " +
        "u=" + u + ", " +
        "v=" + v + ", " +
        "normal=" + normal + ", " +
        "tangent=" + tangent + ")";
    } // ToString()
    #endregion

    #region Generate vertex declaration
    /// <summary>
    /// Vertex elements for Mesh.Clone
    /// </summary>
    public static readonly VertexElement[] VertexElements =
      GenerateVertexElements();

    /// <summary>
    /// Vertex declaration for vertex buffers.
    /// </summary>
    public static VertexDeclaration VertexDeclaration =
      new VertexDeclaration(MainForm.DirectXDevice, VertexElements);

    /// <summary>
    /// Generate vertex declaration
    /// </summary>
    private static VertexElement[] GenerateVertexElements()
    {
      VertexElement[] decl = new VertexElement[]
        {
          // Construct new vertex declaration with tangent info
          // First the normal stuff (we should already have that)
          new VertexElement(0, 0, DeclarationType.Float3,
          DeclarationMethod.Default, DeclarationUsage.Position, 0),
          new VertexElement(0, 12, DeclarationType.Float2,
          DeclarationMethod.Default, DeclarationUsage.TextureCoordinate, 0),
          new VertexElement(0, 20, DeclarationType.Float3,
          DeclarationMethod.Default, DeclarationUsage.Normal, 0),
          // And now the tangent
          new VertexElement(0, 32, DeclarationType.Float3,
          DeclarationMethod.Default, DeclarationUsage.Tangent, 0),
          VertexElement.VertexDeclarationEnd,
      };
      return decl;
    } // GenerateVertexElements()
    #endregion

    #region Is declaration tangent vertex declaration
    /// <summary>
    /// Returns true if declaration is tangent vertex declaration.
    /// </summary>
    public static bool IsTangentVertexDeclaration(
      VertexElement[] declaration)
    {
      return
        declaration[0].DeclarationUsage == DeclarationUsage.Position &&
        declaration[1].DeclarationUsage ==
        DeclarationUsage.TextureCoordinate &&
        declaration[2].DeclarationUsage == DeclarationUsage.Normal &&
        declaration[3].DeclarationUsage == DeclarationUsage.Tangent &&
        declaration[4].DeclarationType == DeclarationType.Unused;
    } // IsTangentVertexDeclaration(declaration)
    #endregion
  } // struct TangentVertex
} // namespace NormalMapCompressor
