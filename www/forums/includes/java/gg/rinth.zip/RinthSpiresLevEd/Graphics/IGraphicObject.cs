#region Using directives
using System;
using System.Collections;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.Threading;
using System.ComponentModel;
using System.Data;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
#endregion

namespace RinthSpires
{
  /// <summary>
  /// Helper interface for all graphic objects we have to dispose before the
  /// device gets disposed. Added to graphicObjectList in GraphicForm.
  /// Also adds support for handling OnResetDevice and OnLostDevice events.
  /// </summary>
  public interface IGraphicObject : IDisposable
  {
    /// <summary>
    /// Called when DirectX device OnResetDevice happens.
    /// Usually not used or only to regenerate disposed stuff from
    /// OnLostDevice().
    /// </summary>
    void OnResetDevice();

    /// <summary>
    /// Called when DirectX device OnLostDevice happens.
    /// Usually unused, will sometimes call Dispose(), recreate in
    /// OnResetDevice then.
    /// </summary>
    void OnLostDevice();
  }
}
