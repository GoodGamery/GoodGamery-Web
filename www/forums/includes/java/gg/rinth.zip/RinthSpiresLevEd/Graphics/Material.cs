#region Using directives
using System;
using System.Collections;
using System.Text;
using System.Drawing;
using Microsoft.DirectX.Direct3D;
using DirectXMaterial = Microsoft.DirectX.Direct3D.Material;
#endregion

namespace RinthSpires
{
  /// <summary>
  /// Material class for DirectX materials used for Models. Consists of
  /// normal DirectX material settings (ambient, diffuse, specular),
  /// the diffuse texture and optionally of normal map, height map and shader
  /// parameters.
  /// </summary>
  public class Material
  {
    #region Variables

    public static readonly int
      AmbientStart = 100,
      DiffuseStart = 250,
      SpecularStart = 100;

    /// <summary>
    /// Default color values are:
    /// 0.15f for ambient and 1.0f for diffuse and 1.0f specular.
    /// </summary>
    public static readonly Color
      DefaultAmbientColor = Color.FromArgb(AmbientStart, AmbientStart, AmbientStart),
      DefaultDiffuseColor = Color.FromArgb(DiffuseStart, DiffuseStart, DiffuseStart),
      DefaultSpecularColor = Color.FromArgb(SpecularStart, SpecularStart, SpecularStart);

    /// <summary>
    /// Default shininess (24)
    /// </summary>
    const float DefaultShininess = 24.0f;

    /// <summary>
    /// Internally used Direct3D Material for ambient, diffuse and specular
    /// components. This are the basic features for a material together
    /// with the texture.
    /// </summary>
    public DirectXMaterial d3dMaterial;

    /// <summary>
    /// Diffuse texture for the material. Can be null for unused.
    /// </summary>
    public Texture diffuseTexture = null;
    /// <summary>
    /// Normal texture in case we use normal mapping. Can be null for unused.
    /// </summary>
    public Texture normalTexture = null;
    /// <summary>
    /// Height texture in case we use parallax mapping. Can be null for unused.
    /// </summary>
    public Texture heightTexture = null;

    /// <summary>
    /// Parallax amount for parallax and offset shaders.
    /// </summary>
    public const float DefaultParallaxAmount = 0.04f;//0.07f;
    /// <summary>
    /// Parallax amount for parallax and offset shaders.
    /// </summary>
    public float parallaxAmount = DefaultParallaxAmount;
    #endregion

    #region Properties
    /// <summary>
    /// Direct3D Material
    /// </summary>
    /// <returns>DirectXMaterial</returns>
    public DirectXMaterial D3DMaterial
    {
      get
      {
        return d3dMaterial;
      } // get
      set
      {
        d3dMaterial = value;
      } // set
    } // D3DMaterial

    /// <summary>
    /// Checks if the diffuse texture has alpha
    /// </summary>
    public bool HasAlpha
    {
      get
      {
        if (diffuseTexture != null)
          return diffuseTexture.HasAlphaPixels;
        else
          return false;
      } // get
    } // HasAlpha
    #endregion

    #region Select material without shader
    /// <summary>
    /// Select this material for DirectX, will just set the material and
    /// the diffuse texture. Use this only for normal rendering without any
    /// shaders.
    /// </summary>
    public void SelectWithoutShader()
    {
      MainForm.DirectXDevice.Material = D3DMaterial;

      // Diffuse texture set?
      if (diffuseTexture != null)
        // Just set texture
        diffuseTexture.Select();
      else
        MainForm.DirectXDevice.SetTexture(0, null);
    } 
    #endregion

    #region Constructors
    /// <summary>
    /// Create material, just using default values.
    /// </summary>
    public Material()
    {
      d3dMaterial = new DirectXMaterial();
      d3dMaterial.Ambient = DefaultAmbientColor;
      d3dMaterial.Diffuse = DefaultDiffuseColor;
      d3dMaterial.Specular = DefaultSpecularColor;
      d3dMaterial.SpecularSharpness = DefaultShininess;
    } 

    /// <summary>
    /// Create material, just using default color values.
    /// </summary>
    public Material(string setDiffuseTexture)
    {
      d3dMaterial = new DirectXMaterial();
      d3dMaterial.Ambient = DefaultAmbientColor;
      d3dMaterial.Diffuse = DefaultDiffuseColor;
      d3dMaterial.Specular = DefaultSpecularColor;
      d3dMaterial.SpecularSharpness = DefaultShininess;
      diffuseTexture = new Texture(setDiffuseTexture);
    } 

    /// <summary>
    /// Create material
    /// </summary>
    public Material(DirectXMaterial setMaterial, string setDiffuseTexture)
    {
      d3dMaterial = setMaterial;
      diffuseTexture = new Texture(setDiffuseTexture);
    } 

    /// <summary>
    /// Create material
    /// </summary>
    public Material(Color ambientColor, Color diffuseColor,
      string setDiffuseTexture)
    {
      d3dMaterial = new DirectXMaterial();
      d3dMaterial.Ambient = ambientColor;
      d3dMaterial.Diffuse = diffuseColor;
      d3dMaterial.Specular = DefaultSpecularColor;
      d3dMaterial.SpecularSharpness = DefaultShininess;
      diffuseTexture = new Texture(setDiffuseTexture);

      // Leave rest to default
    } // Material(ambientColor, diffuseColor, setDiffuseTexture)

    /// <summary>
    /// Create material
    /// </summary>
    public Material(Color ambientColor, Color diffuseColor,
      Texture setDiffuseTexture)
    {
      d3dMaterial = new DirectXMaterial();
      d3dMaterial.Ambient = ambientColor;
      d3dMaterial.Diffuse = diffuseColor;
      d3dMaterial.Specular = DefaultSpecularColor;
      d3dMaterial.SpecularSharpness = DefaultShininess;
      diffuseTexture = setDiffuseTexture;

      // Leave rest to default
    } // Material(ambientColor, diffuseColor, setDiffuseTexture)

    /// <summary>
    /// Create material
    /// </summary>
    public Material(
      ExtendedMaterial copyFromExtendedMaterial)
    {
      LoadExtendedMaterial(copyFromExtendedMaterial);

      // Leave rest to default
    } // Material(copyFromExtendedMaterial)

    /// <summary>
    /// Load extended material
    /// </summary>
    /// <param name="extendedMaterial">Extended DirectX material</param>
    private void LoadExtendedMaterial(ExtendedMaterial extendedMaterial)
    {
      d3dMaterial = extendedMaterial.Material3D;
      // Don't let go shininess below 4, looks not good for vertices.
      if (d3dMaterial.SpecularSharpness < 4)
        d3dMaterial.SpecularSharpness = 4;

      // Load texture and cut off extension, modelers may use different
      // file format, we want only our default format dds.
      string textureFilename =
        StringHelper.ExtractFilename(
        extendedMaterial.TextureFilename, true);
      // If material has no texture, then set texture to null
      if (textureFilename.Length == 0)
        diffuseTexture = null;
      else
        // Load using the models directory
        //-- directory
        diffuseTexture = new Texture(textureFilename);

      // When texture was loaded properly set all material colors
      // to default because 3ds max does the same thing, nothing is used!
      if (diffuseTexture != null &&
        diffuseTexture.D3DTexture != null)
      {
        d3dMaterial.Ambient = DefaultAmbientColor;
        d3dMaterial.Diffuse = DefaultDiffuseColor;
        d3dMaterial.Specular = DefaultSpecularColor;
        d3dMaterial.SpecularSharpness = DefaultShininess;
      } // if (diffuseTexture)
      else
      {
        // Ambient color of 0 isn't cool.
        if (d3dMaterial.Ambient.R < DefaultAmbientColor.R)
          d3dMaterial.Ambient = DefaultAmbientColor;
      } // else
    } // LoadExtendedMaterial(dxMaterial)
    #endregion

    #region Helpers for creating material from shader parameters
    /// <summary>
    /// Search effect parameter
    /// </summary>
    /// <param name="parameters">Parameters</param>
    /// <param name="paramName">Param name</param>
    /// <returns>Object</returns>
    private static object SearchEffectParameter(
      EffectDefault[] parameters, string paramName)
    {
      foreach (EffectDefault param in parameters)
      {
        if (StringHelper.Compare(param.ParameterName, paramName))
        {
          return param.Data;
        } // if (StringHelper.Compare)
      } // foreach (param in parameters)
      // Not found
      return null;
    } // SearchEffectParameter(parameters, paramName)

    /// <summary>
    /// Search effect float parameter
    /// </summary>
    /// <param name="parameters">Parameters</param>
    /// <param name="paramName">Param name</param>
    /// <param name="defaultValue">Default value</param>
    /// <returns>Float</returns>
    private static float SearchEffectFloatParameter(
      EffectDefault[] parameters, string paramName, float defaultValue)
    {
      object ret = SearchEffectParameter(parameters, paramName);
      if (ret != null &&
        ret.GetType() == typeof(float))
        return (float)ret;
      // Not found? Then just return default value.
      return defaultValue;
    } // SearchEffectFloatParameter(parameters, paramName, defaultValue)

    /// <summary>
    /// Search effect color parameter
    /// </summary>
    /// <param name="parameters">Parameters</param>
    /// <param name="paramName">Param name</param>
    /// <param name="defaultColor">Default color</param>
    /// <returns>Color</returns>
    private static Color SearchEffectColorParameter(
      EffectDefault[] parameters, string paramName, Color defaultColor)
    {
      object ret = SearchEffectParameter(parameters, paramName);
      if (ret != null &&
        ret.GetType() == typeof(float[]))
      {
        float[] data = (float[])ret;
        if (data.Length >= 4)
        {
          byte red = (byte)(data[0] * 255.0f);
          byte green = (byte)(data[1] * 255.0f);
          byte blue = (byte)(data[2] * 255.0f);
          byte alpha = (byte)(data[3] * 255.0f);
          return Color.FromArgb(alpha, red, green, blue);
        } // if (data.Length)
      } // if (ret)
      // Not found? Then just return default value.
      return defaultColor;
    } // SearchEffectColorParameter(parameters, paramName, defaultColor)

    /// <summary>
    /// Search effect texture parameter
    /// </summary>
    /// <param name="parameters">Parameters</param>
    /// <param name="paramName">Param name</param>
    /// <param name="defaultTexture">Default texture</param>
    /// <returns>Texture</returns>
    private static Texture SearchEffectTextureParameter(
      EffectDefault[] parameters, string paramName, Texture defaultTexture)
    {
      object ret = SearchEffectParameter(parameters, paramName);
      if (ret != null &&
        ret.GetType() == typeof(string))
      {
        // Use the models directory
        return new Texture(StringHelper.ExtractFilename((string)ret, true));
          //-- directory
          
      } // if (ret)
      // Not found? Then just return default value.
      return defaultTexture;
    } // SearchEffectTextureParameter(parameters, paramName, defaultTexture)
    #endregion

    #region Constructor for creating material from EffectInstance from x file
    /// <summary>
    /// Material
    /// </summary>
    public Material(EffectInstance modelEffectInstance,
      ExtendedMaterial dxMaterial)
    {
      EffectDefault[] parameters = modelEffectInstance.GetDefaults();

      LoadExtendedMaterial(dxMaterial);


        if (diffuseTexture == null)
          diffuseTexture = SearchEffectTextureParameter( parameters, "diffuseTexture", null);


        return;
      
    
    } 
    #endregion
  } 
} 
