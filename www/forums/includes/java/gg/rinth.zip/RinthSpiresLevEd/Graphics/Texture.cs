#region Using directives
using System;
using System.Drawing;
using System.IO;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using Direct3D = Microsoft.DirectX.Direct3D;
using System.Windows.Forms;
#endregion

namespace RinthSpires
{
	/// <summary>
	/// Texture class helping you with using DirectX Textures and handling
	/// possible errors that can happen while loading (stupid DirectX
	/// error messages telling you absolutly nothing, so a lot of pre-checks
	/// help you determinate the error before even calling DirectX methods).
	/// </summary>
	public class Texture : IGraphicObject
	{
		#region Variables
		/// <summary>
		/// If you want to add a default extension if none is given, set it here.
		/// If this is empty, no default extension will be applied.
		/// </summary>
		protected const string AddExtensionIfNoneGiven = "tga";

		/// <summary>
		/// Texture filename
		/// </summary>
		protected string texFilename = "";
		/// <summary>
		/// Get filename of texture.
		/// </summary>
		public string Filename
		{
			get
			{
				return texFilename;
			} // get
		} // Filename

		/// <summary>
		/// Size of texture
		/// </summary>
		protected Size size;
		/// <summary>
		/// Size of texture
		/// </summary>
		public Size TextureSize
		{
			get
			{
				return size;
			} // get
		} // TextureSize

		/// <summary>
		/// Width of texture
		/// </summary>
		public int Width
		{
			get
			{
				return size.Width;
			} // get
		} // Width
		/// <summary>
		/// Height of texture
		/// </summary>
		public int Height
		{
			get
			{
				return size.Height;
			} // get
		} // Height

		/// <summary>
		/// Size of half a pixel, will be calculated when size is set.
		/// </summary>
		private Vector2 precaledHalfPixelSize = Vector2.Empty;
		/// <summary>
		/// Get the size of half a pixel, used to correct texture
		/// coordinates when rendering on screen, see Texture.RenderOnScreen.
		/// </summary>
		public Vector2 HalfPixelSize
		{
			get
			{
				return precaledHalfPixelSize;
			} // get
		} // HalfPixelSize

		/// <summary>
		/// Calc half pixel size
		/// </summary>
		protected void CalcHalfPixelSize()
		{
			precaledHalfPixelSize = new Vector2(
				(1.0f / (float)size.Width) / 2.0f,
				(1.0f / (float)size.Height) / 2.0f);
		} // CalcHalfPixelSize()

		/// <summary>
		/// Graphic Texture
		/// </summary>
		protected Direct3D.Texture direct3dTexture = null;
		/// <summary>
		/// Direct3D texture
		/// </summary>
		public Direct3D.Texture D3DTexture
		{
			get
			{
				return direct3dTexture;
			} // get
		} // D3DTexture

		/// <summary>
		/// Loading succeeded?
		/// </summary>
		protected bool loaded = true;
		/// <summary>
		/// Error?
		/// </summary>
		protected string error = "";

		/// <summary>
		/// Is texture valid? Will be false if loading failed.
		/// </summary>
		public virtual bool Valid
		{
			get
			{
				return loaded && direct3dTexture != null;
			} // get
		} // Valid

		/// <summary>
		/// Has alpha?
		/// </summary>
		protected bool hasAlpha = false;
		/// <summary>
		/// Has texture alpha information?
		/// </summary>
		public bool HasAlphaPixels
		{
			get
			{
				return hasAlpha;
			} // get
		} // HasAlphaPixels
		#endregion

		#region Constructor
		/// <summary>
		/// Create texture
		/// </summary>
		protected Texture()
		{
		} // Texture()

		/// <summary>
		/// Create texture from given filename.
		/// </summary>
		/// <param name="setFilename">Set filename, must be relative and be a
		/// valid file in the textures directory.</param>
		public Texture(string setFilename)
		{

			if (setFilename == "")
				throw new ArgumentNullException("setFilename",
					"Unable to create texture without valid filename.");

			// Add default extension if none is given
			if (AddExtensionIfNoneGiven.Length > 0 &&
				StringHelper.GetExtension(setFilename).Length == 0)
				setFilename = setFilename + "." + AddExtensionIfNoneGiven;

			// Set filename
			texFilename = setFilename;

			// Try to load texture
			try
			{
				// Build full filename
        //-- directories
				string fullFilename = setFilename;

				// Check if file exists, else we can't continue loading!
				if (File.Exists(fullFilename) == false)
					throw new FileNotFoundException(fullFilename);

				ImageInformation imageInfo =
					TextureLoader.ImageInformationFromFile(fullFilename);
				size = new Size(imageInfo.Width, imageInfo.Height);

				// Size of 0 is not allowed!
				if (size.Width == 0 || size.Height == 0)
					throw new InvalidOperationException(
						"Image size="+size+" is invalid, unable to init texture.");
				CalcHalfPixelSize();

				// We will use alpha for Dxt3, Dxt5 or any format starting with "A",
				// there are a lot of those (A8R8G8B8, A4R4G4B4, A8B8G8R8, etc.)
				hasAlpha = true;/*
					imageInfo.Format == Format.Dxt5 ||
					imageInfo.Format == Format.Dxt3 ||
					imageInfo.Format.ToString().StartsWith("A");*/

				// Finally load texture
        /*
				direct3dTexture = TextureLoader.FromFile(
					MainForm.DirectXDevice,
					fullFilename);*/

        direct3dTexture = TextureLoader.FromFile(MainForm.DirectXDevice, fullFilename, 0, 0, 1, 
          Usage.None, Format.Unknown, Pool.Managed, Filter.None, Filter.None, 0);

				loaded = true;

				GameClass.GraphicObjects.Add(this);
			} // try
			catch (Exception ex)
			{
				// Failed to load
				loaded = false;
				Console.WriteLine("Failed to load texture " + setFilename +
					", will use empty texture! Error: " + ex.ToString());
			} // catch (ex)
		} // Texture(setFilename)
		#endregion

		#region Disposing
		/// <summary>
		/// Dispose
		/// </summary>
		public virtual void Dispose()
		{
			if (direct3dTexture != null)
				 direct3dTexture.Dispose();
			direct3dTexture = null;
			loaded = false;
		} // Dispose()
		#endregion

		#region IGraphicObject Members
		/// <summary>
		/// On reset device
		/// </summary>
		public virtual void OnResetDevice()
		{
		} // OnResetDevice()

		/// <summary>
		/// On lost device
		/// </summary>
		public virtual void OnLostDevice()
		{
		} // OnLostDevice()
		#endregion

		#region Select texture as texture stage
		/// <summary>
		/// Select this texture as texture stage 0
		/// </summary>
		public virtual void Select()
		{
			if (direct3dTexture != null)
				MainForm.DirectXDevice.SetTexture(0, direct3dTexture);
		} // Select()
		#endregion

		#region Rendering on screen
		/// <summary>
		/// Render texture at rect directly on screen using texture cordinates.
		/// </summary>
		public void RenderOnScreen(Rectangle rect,
			float u1, float v1, float u2, float v2)
		{
			// Don't continue if texture is not valid
			if (Valid == false ||
				MainForm.DirectXDevice == null)
				return;

			Direct3D.CustomVertex.TransformedTextured[] screenVertices =
				new Direct3D.CustomVertex.TransformedTextured[4];
			// Note: DirectX uses some gay sort of rendering transformed
			// texture coordinates and will render everything with centered
			// pixels (this means pixel 0, 0 with tex coord (0.0f, 0.0f) is
			// not really the upper left, but the center of the first pixel).
			// This results in a blurry texture even when rendering at exactly
			// the correct size of the texture on screen.
			// To fix this we simply substract half the pixel size for u and v!
			Vector2 screenChange = new Vector2(-0.5f, -0.5f);
			screenVertices[0] = new Direct3D.CustomVertex.TransformedTextured(
				rect.X + screenChange.X, rect.Y + screenChange.Y, 1.0f, 1.0f,
				u1, v1);
			screenVertices[1] = new Direct3D.CustomVertex.TransformedTextured(
				rect.Right + screenChange.X, rect.Y + screenChange.Y, 1.0f, 1.0f,
				u2, v1);
			screenVertices[2] = new Direct3D.CustomVertex.TransformedTextured(
				rect.Right + screenChange.X, rect.Bottom + screenChange.Y, 1.0f, 1.0f,
				u2, v2);
			screenVertices[3] = new Direct3D.CustomVertex.TransformedTextured(
				rect.X + screenChange.X, rect.Bottom + screenChange.Y, 1.0f, 1.0f,
				u1, v2);

			// Set texture and render it with vertices on screen
			try
			{
				// Select texture
				Select();

				MainForm.DirectXDevice.VertexFormat = Direct3D.CustomVertex.TransformedTextured.Format;
				MainForm.DirectXDevice.DrawUserPrimitives(Direct3D.PrimitiveType.TriangleFan, screenVertices.Length - 2, screenVertices);
			} // try
#if DEBUG
			catch (Exception ex)
			{
				Console.WriteLine(
					"DrawUserPrimitives for rendering texture fails: " + ex.ToString());
				// Rethrow error to find cause
				throw;
			} // catch (ex)
#else 
			catch { } // ignore
#endif
		} // RenderOnScreen(rect, u1, v1)

		/// <summary>
		/// Render texture at rect directly on screen using full texture.
		/// </summary>
		public void RenderOnScreen(Rectangle rect)
		{
			RenderOnScreen(rect, 0.0f, 0.0f, 1.0f, 1.0f);
		} // RenderOnScreen(rect)

		/// <summary>
		/// Render texture at rect directly on screen using full texture.
		/// </summary>
		public void RenderOnScreen(Rectangle rect, Rectangle pixelRect)
		{
			RenderOnScreen(rect,
				(float)pixelRect.X / (float)size.Width,
				(float)pixelRect.Y / (float)size.Height,
				(float)pixelRect.Right / (float)size.Width,
				(float)pixelRect.Bottom / (float)size.Height);
		} // RenderOnScreen(rect)

		/// <summary>
		/// Render texture at rect directly on screen using texture cordinates.
		/// This method allows to render with specific color and alpha values.
		/// </summary>
		public void RenderOnScreen(Rectangle rect,
			float u1, float v1, float u2, float v2,
			Color color, float alpha)
		{
			// Don't continue if texture is not valid or rect is not on screen!
			if (Valid == false ||
				MainForm.DirectXDevice == null)
				return;

			// Use argb color format and set alpha
			int argbColor = Color.FromArgb(
				(byte)(255 * alpha), color.R, color.G, color.B).ToArgb();

			// Note: DirectX uses some gay sort of rendering transformed
			// texture coordinates and will render everything with centered
			// pixels (this means pixel 0, 0 with tex coord (0.0f, 0.0f) is
			// not really the upper left, but the center of the first pixel).
			// This results in a blurry texture even when rendering at exactly
			// the correct size of the texture on screen.
			// To fix this we simply substract half the pixel size for u and v!
			Direct3D.CustomVertex.TransformedColoredTextured[] screenVertices =
				new Direct3D.CustomVertex.TransformedColoredTextured[4];
			Vector2 screenChange = new Vector2(-0.5f, -0.5f);
			screenVertices[0] = new Direct3D.CustomVertex.TransformedColoredTextured(
				rect.X + screenChange.X, rect.Y + screenChange.Y, 1.0f, 1.0f,
				argbColor,
				u1, v1);
			screenVertices[1] = new Direct3D.CustomVertex.TransformedColoredTextured(
				rect.Right + screenChange.X, rect.Y + screenChange.Y, 1.0f, 1.0f,
				argbColor,
				u2, v1);
			screenVertices[2] = new Direct3D.CustomVertex.TransformedColoredTextured(
				rect.Right + screenChange.X, rect.Bottom + screenChange.Y, 1.0f, 1.0f,
				argbColor,
				u2, v2);
			screenVertices[3] = new Direct3D.CustomVertex.TransformedColoredTextured(
				rect.X + screenChange.X, rect.Bottom + screenChange.Y, 1.0f, 1.0f,
				argbColor,
				u1, v2);

			// Set texture and render it with vertices on screen
			try
			{
				// SelectWithoutShader texture (will work for animated textures too)
				Select();

				MainForm.DirectXDevice.VertexFormat =
					Direct3D.CustomVertex.TransformedColoredTextured.Format;
				MainForm.DirectXDevice.DrawUserPrimitives(
					Direct3D.PrimitiveType.TriangleFan,
					screenVertices.Length - 2, screenVertices);
			} // try
#if DEBUG
			catch (Exception ex)
			{
				Console.WriteLine(
					"DrawUserPrimitives for rendering texture fails: " + ex.ToString());
				// Rethrow error to find cause
				throw;
			} // catch (ex)
#else 
			catch { } // ignore
#endif
		} // RenderOnScreen(rect, u1, v1)
		
		/// <summary>
		/// Render texture at rect directly on screen using texture cordinates.
		/// This method allows to render with specific color and alpha values.
		/// </summary>
		public void RenderOnScreen(Rectangle rect, Color color, float alpha)
		{
			RenderOnScreen(rect, 0, 0, 1, 1, color, alpha);
		} // RenderOnScreen(rect, color, alpha)

		/// <summary>
		/// Render texture at rect directly on screen using texture cordinates.
		/// This method allows to render with specific color and alpha values.
		/// </summary>
		public void RenderOnScreen(Rectangle rect, Rectangle pixelRect,
			Color color, float alpha)
		{
			RenderOnScreen(rect,
				(float)pixelRect.X / (float)size.Width,
				(float)pixelRect.Y / (float)size.Height,
				(float)pixelRect.Right / (float)size.Width,
				(float)pixelRect.Bottom / (float)size.Height,
				color, alpha);
		} // RenderOnScreen(rect)

		/// <summary>
		/// Render on screen with z buffer, same as RenderOnScreen, but uses
		/// zValue for the z coordinate (must be between 0 and 1). Be sure
		/// to enable Z-Buffering before calling this method or it will have no
		/// effect.
		/// </summary>
		/// <param name="rect">Rectangle</param>
		/// <param name="u1">U texture coordinate 1</param>
		/// <param name="v1">V texture coordinate 1</param>
		/// <param name="u2">U texture coordinate 2</param>
		/// <param name="v2">V texture coordinate 2</param>
		/// <param name="zValue">Z value</param>
		public void RenderOnScreenWithZBuffer(Rectangle rect,
			float u1, float v1, float u2, float v2, float zValue)
		{
			// Don't continue if texture is not valid or rect is not on screen!
			if (Valid == false ||
				MainForm.DirectXDevice == null)
				return;

			Direct3D.CustomVertex.TransformedTextured[] screenVertices =
				new Direct3D.CustomVertex.TransformedTextured[4];
			Vector2 screenChange = new Vector2(-0.5f, -0.5f);
			// See above for notes.
			screenVertices[0] = new Direct3D.CustomVertex.TransformedTextured(
				rect.X + screenChange.X, rect.Y + screenChange.Y, zValue, 0.0f,
				u1, v1);
			screenVertices[1] = new Direct3D.CustomVertex.TransformedTextured(
				rect.Right + screenChange.X, rect.Y + screenChange.Y, zValue, 0.0f,
				u2, v1);
			screenVertices[2] = new Direct3D.CustomVertex.TransformedTextured(
				rect.Right + screenChange.X, rect.Bottom + screenChange.Y, zValue, 0.0f,
				u2, v2);
			screenVertices[3] = new Direct3D.CustomVertex.TransformedTextured(
				rect.X + screenChange.X, rect.Bottom + screenChange.Y, zValue, 0.0f,
				u1, v2);

			// Set texture and render it with vertices on screen
			try
			{
				// Select texture
				Select();

				MainForm.DirectXDevice.VertexFormat =
					Direct3D.CustomVertex.TransformedTextured.Format;
				MainForm.DirectXDevice.DrawUserPrimitives(
					Direct3D.PrimitiveType.TriangleFan,
					screenVertices.Length - 2, screenVertices);
			} // try
#if DEBUG
			catch (Exception ex)
			{
				Console.WriteLine(
					"DrawUserPrimitives for rendering texture fails: " + ex.ToString());
				// Rethrow error to find cause
				throw;
			} // catch (ex)
#else 
			catch { } // ignore
#endif
		} // RenderOnScreenWithZBuffer(rect, u1, v1)

		/// <summary>
		/// Render on screen with z buffer
		/// </summary>
		/// <param name="rect">Rectangle</param>
		/// <param name="zValue">Z value</param>
		public void RenderOnScreenWithZBuffer(Rectangle rect, float zValue)
		{
			RenderOnScreenWithZBuffer(rect, 0, 0, 1, 1, zValue);
		} // RenderOnScreenWithZBuffer(rect, zValue)

		/// <summary>
		/// Render on screen with z buffer
		/// </summary>
		/// <param name="rect">Rectangle</param>
		/// <param name="pixelRect">Pixel rectangle</param>
		/// <param name="zValue">Z value</param>
		public void RenderOnScreenWithZBuffer(
			Rectangle rect, Rectangle pixelRect, float zValue)
		{
			RenderOnScreenWithZBuffer(rect,
				(float)pixelRect.X / (float)size.Width,
				(float)pixelRect.Y / (float)size.Height,
				(float)pixelRect.Right / (float)size.Width,
				(float)pixelRect.Bottom / (float)size.Height,
				zValue);
		} // RenderOnScreenWithZBuffer(rect, pixelRect, zValue)
		#endregion

		#region Rendering on screen with rotation
		/// <summary>
		/// Render on screen with rotation
		/// </summary>
		/// <param name="pos">Position</param>
		/// <param name="size">Size</param>
		/// <param name="rotation">Rotation</param>
		/// <param name="u1">U texture coordinate 1</param>
		/// <param name="v1">V texture coordinate 1</param>
		/// <param name="u2">U texture coordinate 2</param>
		/// <param name="v2">V texture coordinate 2</param>
		public void RenderOnScreenWithRotation(
			Point pos, float size, float rotation,
			float u1, float v1, float u2, float v2)
		{
			// Don't continue if texture is not valid
			if (Valid == false ||
				MainForm.DirectXDevice == null)
				return;

			Direct3D.CustomVertex.TransformedTextured[] screenVertices =
				new Direct3D.CustomVertex.TransformedTextured[4];

			Vector2 right = new Vector2(
				+(float)Math.Cos(rotation),
				+(float)Math.Sin(rotation));
			Vector2 up = new Vector2(
				+(float)Math.Sin(rotation),
				-(float)Math.Cos(rotation));

			Rectangle rect = new Rectangle(pos.X, pos.Y, (int)size, (int)size);
			screenVertices[0] = new Direct3D.CustomVertex.TransformedTextured(
				pos.X + ((-right.X - up.X) * size),
				pos.Y + ((-right.Y - up.Y) * size), 1.0f, 1.0f,
				u1, v1);
			screenVertices[1] = new Direct3D.CustomVertex.TransformedTextured(
				pos.X + ((-right.X + up.X) * size),
				pos.Y + ((-right.Y + up.Y) * size), 1.0f, 1.0f,
				u2, v1);
			screenVertices[2] = new Direct3D.CustomVertex.TransformedTextured(
				pos.X + ((right.X + up.X) * size),
				pos.Y + ((right.Y + up.Y) * size), 1.0f, 1.0f,
				u2, v2);
			screenVertices[3] = new Direct3D.CustomVertex.TransformedTextured(
				pos.X + ((right.X - up.X) * size),
				pos.Y + ((right.Y - up.Y) * size), 1.0f, 1.0f,
				u1, v2);

			// Select texture
			Select();
			// Render it with vertices
			MainForm.DirectXDevice.VertexFormat =
				Direct3D.CustomVertex.TransformedTextured.Format;
			MainForm.DirectXDevice.DrawUserPrimitives(
				Direct3D.PrimitiveType.TriangleFan,
				screenVertices.Length - 2,
				screenVertices);
		} // RenderOnScreenWithRotation(pos, size, rotation)

		/// <summary>
		/// Render on screen with rotation
		/// </summary>
		/// <param name="pos">Position</param>
		/// <param name="setSize">Size</param>
		/// <param name="rotation">Rotation</param>
		/// <param name="pixelRect">Pixel rectangle</param>
		public void RenderOnScreenWithRotation(
			Point pos, float setSize, float rotation, Rectangle pixelRect)
		{
			RenderOnScreenWithRotation(pos, setSize, rotation,
				(float)pixelRect.X / (float)size.Width,
				(float)pixelRect.Y / (float)size.Height,
				(float)pixelRect.Right / (float)size.Width,
				(float)pixelRect.Bottom / (float)size.Height);
		} // RenderOnScreenWithRotation(pos, size, rotation)

		/// <summary>
		/// Render on screen with rotation
		/// </summary>
		/// <param name="pos">Position</param>
		/// <param name="size">Size</param>
		/// <param name="rotation">Rotation</param>
		/// <param name="u1">U texture coordinate 1</param>
		/// <param name="v1">V texture coordinate 1</param>
		/// <param name="u2">U texture coordinate 2</param>
		/// <param name="v2">V texture coordinate 2</param>
		public void RenderOnScreenWithRotation(
			Point pos, float size, float rotation,
			float u1, float v1, float u2, float v2,
			Color color, float alpha)
		{
			// Don't continue if texture is not valid
			if (Valid == false ||
				MainForm.DirectXDevice == null)
				return;

			Direct3D.CustomVertex.TransformedColoredTextured[] screenVertices =
				new Direct3D.CustomVertex.TransformedColoredTextured[4];

			Vector2 right = new Vector2(
				+(float)Math.Cos(rotation),
				+(float)Math.Sin(rotation));
			Vector2 up = new Vector2(
				+(float)Math.Sin(rotation),
				-(float)Math.Cos(rotation));

			// Use argb color format and set alpha
			int argbColor = Color.FromArgb(
				(byte)(255 * alpha), color.R, color.G, color.B).ToArgb();

			Rectangle rect = new Rectangle(pos.X, pos.Y, (int)size, (int)size);
			screenVertices[0] = new Direct3D.CustomVertex.TransformedColoredTextured(
				pos.X + ((-right.X - up.X) * size),
				pos.Y + ((-right.Y - up.Y) * size), 1.0f, 1.0f,
				argbColor,
				u1, v1);
			screenVertices[1] = new Direct3D.CustomVertex.TransformedColoredTextured(
				pos.X + ((-right.X + up.X) * size),
				pos.Y + ((-right.Y + up.Y) * size), 1.0f, 1.0f,
				argbColor,
				u2, v1);
			screenVertices[2] = new Direct3D.CustomVertex.TransformedColoredTextured(
				pos.X + ((right.X + up.X) * size),
				pos.Y + ((right.Y + up.Y) * size), 1.0f, 1.0f,
				argbColor,
				u2, v2);
			screenVertices[3] = new Direct3D.CustomVertex.TransformedColoredTextured(
				pos.X + ((right.X - up.X) * size),
				pos.Y + ((right.Y - up.Y) * size), 1.0f, 1.0f,
				argbColor,
				u1, v2);

			// Select texture
			Select();
			// Render it with vertices
			MainForm.DirectXDevice.VertexFormat =
				Direct3D.CustomVertex.TransformedColoredTextured.Format;
			MainForm.DirectXDevice.DrawUserPrimitives(
				Direct3D.PrimitiveType.TriangleFan,
				screenVertices.Length - 2,
				screenVertices);
		} // RenderOnScreenWithRotation(pos, size, rotation)
		#endregion

		#region To string
		/// <summary>
		/// To string
		/// </summary>
		public override string ToString()
		{
			return "Texture(filename=" + texFilename +
				", size=" + size +
				", d3dTexture=" + (direct3dTexture != null ? "valid" : "null") +
				", hasAlpha=" + hasAlpha + ")";
		} // ToString()
		#endregion
	} 
} 

