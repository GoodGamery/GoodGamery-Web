#region Using directives
using System;
using System.Collections;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Globalization;
using System.Drawing;
using System.Threading;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using Direct3D = Microsoft.DirectX.Direct3D;
using Material = RinthSpires.Material;
using Effect = Microsoft.DirectX.Direct3D.Effect;
#endregion

namespace RinthSpires
{
	/// <summary>
	/// Model class for loading and displaying x files including all materials
	/// and textures. Provides load and render functions to render static
	/// non animated models (mostly 1 mesh), for animated models we need a more
	/// advanced class, which is not required for this game yet.
	/// </summary>
	public class Model : IGraphicObject
	{
		#region Variables
		/// <summary>
		/// Extension for Models, we use the .x format here :)
		/// </summary>
		public const string Extension = "x";

		/// <summary>
		/// Direct3D Mesh used here, everything is collapsed to this mesh.
		/// </summary>
		protected Mesh d3dMesh = null;

		/// <summary>
		/// List of all used materials for this model.
		/// Used as attribute parameter for DrawSubset when rendering.
		/// Note: For this game we only use models with 1 material. If you have
		/// multiple materials, you should not only sort the rendering by models,
		/// but by materials to speed up the rendering process (see instancing).
		/// </summary>
		protected Material[] materials = null;

		/// <summary>
		/// The model .x file
		/// </summary>
		protected string modelFilename = "";

		/// <summary>
		/// The object radius calculated after loading,
		/// only used for objectMatrix
		/// </summary>
		protected float objectRadius = 1.0f;
		/// <summary>
		/// Center of the universe, erm, object, only used for alpha sorting.
		/// </summary>
		protected Vector3 objectCenter;
		/// <summary>
		/// Scale down factor to get everything to Identity!
		/// </summary>
		protected float scaleDownFactor = 1.0f; 
		/// <summary>
		/// Precaled matrix for rendering the model
		/// </summary>
		protected Matrix objectMatrix = new Matrix();
		/// <summary>
		/// Error in case something went wrong while loading.
		/// </summary>
		protected string error = "";

		/// <summary>
		/// Helper list to prevent reloading already loaded materials.
		/// E.g. when loading asteroid1.x, this will load the material
		/// asteroid1 (3 dds files), but asteroid1Low.x uses the same textures
		/// again. This happens a lot for item and asteroid models.
		/// </summary>
		protected static ArrayList alreadyLoadedMaterials = new ArrayList();
		#endregion

		#region Properties
		/// <summary>
		/// Get filename of model
		/// </summary>
		public virtual string Filename
		{
			get
			{
				return modelFilename;
			} // get
		} // Filename

		/// <summary>
		/// Checks if model is valid to render, if this is false,
		/// nothing will be rendered, check Error for detailed error description.
		/// </summary>
		public virtual bool Valid
		{
			get
			{
				return d3dMesh != null && materials != null;
			} // get
		} // Valid

		/// <summary>
		/// Just get the first material, other materials are not supported
		/// for our optimization loop in AsteroidManager.
		/// </summary>
		/// <returns>Material</returns>
		public virtual Material FirstMaterial
		{
			get
			{
				return materials[0];
			} // get
		} // FirstMaterial

		/// <summary>
		/// Get Direct3D mesh
		/// </summary>
		internal virtual Mesh D3DMesh
		{
			get
			{
				return d3dMesh;
			} // get
		} // D3DMesh

		/// <summary>
		/// Get error message if Valid is false and loading failed.
		/// </summary>
		public virtual string ErrorMessage
		{
			get
			{
				return error;
			} // get
		} // ErrorMessage

		/// <summary>
		/// Get object matrix for rendering.
		/// </summary>
		internal Matrix ObjectMatrix
		{
			get
			{
				return objectMatrix;
			} // get
		} // ObjectMatrix

		/// <summary>
		/// Object size
		/// </summary>
		/// <returns>Float</returns>
		public float ObjectSize
		{
			get
			{
				return scaleDownFactor;
			} // get
		} // ObjectSize

		/// <summary>
		/// Calc objectMatrix for rendering, will fix rotation values
		/// provided by the model and scale it to objectRadius to normalize it.
		/// The correctionPosition and the defaultSize is also applied!
		/// </summary>
		protected void CalcObjectMatrix()
		{
			// Only center x and y!
			//objectMatrix = Matrix.Translate(0, 0, 0);
			//don't move it anymore: new Vector3(-center.X, -center.Y, 0.0f));

			scaleDownFactor = objectRadius != 0.0 ? 1.0f / objectRadius : 1.0f;
			objectMatrix =
				Matrix.RotationX(-(float)Math.PI / 2.0f) *
				Matrix.Scaling(
				new Vector3(scaleDownFactor, scaleDownFactor, scaleDownFactor));
		} // CalcObjectMatrix(objectRadius)


		#endregion

		#region Constructor
		/// <summary>
		/// Create model, protected method to only allow derived classes to
		/// call constructor without parameters.
		/// </summary>
		protected Model()
		{
		} // Model()

		/// <summary>
		/// Create model
		/// </summary>
		/// <param name="setFilename">Model filename</param>
		public Model(string setFilename)
		{
			// Add .x extension if it was not given.
			if (StringHelper.GetExtension(setFilename).Length == 0)
				setFilename += "." + Extension;

			modelFilename = setFilename;
      //-- directories
			string fullFilename = modelFilename;
			if (File.Exists(fullFilename) == false)
			{
				d3dMesh = null;
				error = "File " + modelFilename + " does not exists!";
				Console.WriteLine("Failed to load model: " + error);
				return;
			} // if (File.Exists)

			try
			{
				ExtendedMaterial[] extendedMaterials = null;
				EffectInstance[] effectInstances = null;
				d3dMesh = Mesh.FromFile(
					fullFilename,
					MeshFlags.Managed,
					MainForm.DirectXDevice,
					out extendedMaterials,
					out effectInstances);

				materials = new Material[extendedMaterials.Length];
				for (int matNum = 0; matNum < extendedMaterials.Length; matNum++)
				{
					string textureFilename = StringHelper.ExtractFilename(extendedMaterials[matNum].TextureFilename, false);

					// Search for texture filename in shader effect if present.
					if (effectInstances != null && matNum < effectInstances.Length && effectInstances[matNum].EffectFilename != "")
					{
						EffectDefault[] parameters = effectInstances[matNum].GetDefaults();
						foreach (EffectDefault param in parameters)
							if (StringHelper.Compare(param.ParameterName, "diffuseTexture"))
							{
								object ret = param.Data;
								if (ret != null && ret.GetType() == typeof(string))
									textureFilename = StringHelper.ExtractFilename((string)ret, false);
							} 
					} 

					// Material already loaded?
					// Note: In this game we usually only load 1 material per model,
					// more isn't used anyway and some models use the same material
					// on several meshes! Sometimes the same material is loaded
					// for other models too, for that reason alreadyLoadedMaterials
					// should be static!
					// Note: In case we need the same textures, but other material
					// colors and settings, this won't work, you should implement
					// a texture manager class instead.
					foreach (Material loadedMaterial in alreadyLoadedMaterials)
					{
						if (loadedMaterial.diffuseTexture != null &&
							StringHelper.Compare(StringHelper.ExtractFilename(loadedMaterial.diffuseTexture.Filename, false), textureFilename))
						{
							// Reuse existing material
							materials[matNum] = loadedMaterial;
							break;
						}
					}

					// Skip this material if already assigned!
					if (materials[matNum] != null)
						continue;
							
					// Can we use shaders with effect parameters?
					if (effectInstances != null &&
						matNum < effectInstances.Length &&
						effectInstances[matNum].EffectFilename != null &&
						effectInstances[matNum].EffectFilename.Length > 0)
						materials[matNum] = new Material(effectInstances[matNum], extendedMaterials[matNum]);

					// In case no shader was found or shader is not set,
					// load normal material (will render without shader stuff).
					if (materials[matNum] == null)
						materials[matNum] = new Material(extendedMaterials[matNum]);

					// Make sure we don't load this material again!
					alreadyLoadedMaterials.Add(materials[matNum]);
				} 

        /*
				// Calculate the center and radius of a bounding sphere
				// Must be done before we change the vertex format, because
				// Geometry.ComputeBoundingSphere only likes FVF.
				using (GraphicsStream data = d3dMesh.LockVertexBuffer(
					LockFlags.None))
				{
					objectRadius = Geometry.ComputeBoundingSphere(data,
						d3dMesh.NumberVertices, d3dMesh.VertexFormat,
						out objectCenter);
					if (objectRadius == 0.0f)
						objectRadius = 0.01f;

					// Finally unlock the vertex buffer
					d3dMesh.UnlockVertexBuffer();
				} // using (data)
        */

				// Check if mesh has normals and tangents, if not, generate them!
				//GenerateNormalsAndTangentsIfNotPresent(ref d3dMesh, true);

				//CalcObjectMatrix();

        objectMatrix = Matrix.Identity; //Matrix.Identity;

				GameClass.GraphicObjects.Add(this);
			} // try
			catch (Exception ex)
			{
				d3dMesh = null;
				error = ex.Message;
				Console.WriteLine("Failed to load model " + modelFilename +
					", won't display model! Error: " + ex.ToString());
			} // catch (ex)
		} // Model(modelFilename)
		#endregion

		#region Disposing
		/// <summary>
		/// Dispose
		/// </summary>
		public virtual void Dispose()
		{
			if (d3dMesh == null)
				return;
			d3dMesh.Dispose();
			d3dMesh = null;
			modelFilename = "";
		} // Dispose()
		#endregion

		#region IGraphicObject Members
		/// <summary>
		/// On reset device
		/// </summary>
		public void OnResetDevice()
		{
		} // OnResetDevice()

		/// <summary>
		/// On lost device
		/// </summary>
		public void OnLostDevice()
		{
		} // OnLostDevice()
		#endregion

		#region Generate normals and tangents for shaders
		/// <summary>
		/// Generate normals and tangents if not present.
		/// This method is very important for using shaders, most
		/// shader techniques will expect the TangentVertex format!
		/// More help can be found here:
		/// http://exdream.dyn.ee/blog/PermaLink.aspx?guid=e02b46b3-72f1-4cdf-9cb1-7f0861ddbb6b
		/// </summary>
		/// <param name="someMesh">Mesh we are going to manipulate</param>
		/// <param name="weldVerticesFirst">
		/// Weld vertices before generating tangents (so called Rocket mode).
		/// This is VERY useful for organic objects, stones, trees, etc.
		/// Anything with a lot of round surfaces. This introduces a couple
		/// of new problems, but usually looks much better for round surfaces.
		/// If you are sure that the tangents are generated correctly or we
		/// have a lot of single faces not connected on the texture, it is
		/// better to not weld vertices first (e.g. rockets, buildings, etc.)
		/// </param>
		public static void GenerateNormalsAndTangentsIfNotPresent(
			ref Mesh someMesh, bool weldVerticesFirst)
		{
			if (someMesh == null)
				throw new ArgumentNullException("someMesh",
					"Can't generate normals and tangents without valid mesh.");

			// Quick check if vertex declaration of mesh already fits.
			VertexElement[] decl = someMesh.Declaration;
			if (TangentVertex.IsTangentVertexDeclaration(decl))
				// Everything looks fine, leave it that way.
				return;

			bool hadNormals = false;
			bool hadTangents = false;
			// Check the first couple of declaration usages
			for (int i = 0; i < 6 && i < decl.Length; i++)
			{
				if (decl[i].DeclarationUsage == DeclarationUsage.Normal)
				{
					hadNormals = true;
					break;
				} // if (decl[i].DeclarationUsage)
				if (decl[i].DeclarationUsage == DeclarationUsage.Tangent)
				{
					hadTangents = true;
					break;
				} // if (decl[i].DeclarationUsage)
			} // for (int)

			// Create new mesh and clone everything
			Mesh tempMesh = someMesh.Clone(
				someMesh.Options.Value,
				TangentVertex.VertexElements,
				MainForm.DirectXDevice);
			// Destroy current mesh, use the new one
			someMesh.Dispose();
			someMesh = tempMesh;

			// Check if we got texture coordinates, if not, generate them!
			bool gotMilkErmTexCoords = false;
			bool gotValidNormals = true;
			bool gotValidTangents = true;
			TangentVertex[] verts =
				(TangentVertex[])someMesh.LockVertexBuffer(
				typeof(TangentVertex),
				LockFlags.None,
				new int[1] { someMesh.NumberVertices });

			// Check all vertices
			for (int num = 0; num < verts.Length; num++)
			{
				// We only need at least 1 texture coordinate different from (0, 0)
				if (verts[num].u != 0.0f ||
					verts[num].v != 0.0f)
					gotMilkErmTexCoords = true;

				// All normals and tangents must be valid, else generate them below.
				if (verts[num].normal == Vector3.Empty)
					gotValidNormals = false;
				if (verts[num].tangent == Vector3.Empty)
					gotValidTangents = false;

				// If we found valid texture coordinates and no normals or tangents,
				// there isn't anything left to check here.
				if (gotMilkErmTexCoords == true &&
					gotValidNormals == false &&
					gotValidTangents == false)
					break;
			} // for (num, <, ++)

			// If declaration had normals, but we found no valid normals,
			// set hadNormals to false and generate valid normals (see below).
			if (gotValidNormals == false)
				hadNormals = false;
			// Same check for tangents
			if (gotValidTangents == false)
				hadTangents = false;

			// Generate dummy texture coordinates, not only useful for tangent
			// generation, but also unit tests display better visual meshes.
			if (gotMilkErmTexCoords == false)
			{
				for (int num = 0; num < verts.Length; num++)
				{
					// Similar stuff as in GenerateTextureCoordinates, very simple and
					// dummy way to generate texture coordinates from object position.
					// Usually only test objects don't have texture coordinates.
					verts[num].u = -0.75f + verts[num].pos.X / 2.0f;
					verts[num].v = +0.75f - verts[num].pos.Y / 2.0f;
				} // for (num, <, ++)
			} // if (gotMilkErmTexCoords)
			someMesh.UnlockVertexBuffer();

			// Generate normals if this mesh hadn't any.
			if (hadNormals == false)
				someMesh.ComputeNormals();

			// No welding in "Rocket Mode"!
			if (weldVerticesFirst == false)
			{
				if (hadTangents == false)
					someMesh.ComputeTangent(0, 0, D3DX.Default, 0);
				return;
			} // if

			// Ok, first weld vertices which should be together anyway.
			// This optimizes rendering and enables us to do correct tangent
			// calculations below. For example a mesh using around 100 faces might
			// have around 300 vertices, if each face has its own 3 vertices. But
			// when collapsing same vertices together we can get this down to 100-150
			// vertices (which saves half of the bandwidth and vertex memory).
			WeldEpsilons weldEpsilons = new WeldEpsilons();

			// Position and normal should be the same (or nearly the same)
			weldEpsilons.Position = 0.0001f;
			weldEpsilons.Normal = 0.0001f;

			// Rest of the weldEpsilons values can stay 0, we don't use them
			// or if they are used (like texture coord or already generated tangent
			// data, they must be the same for vertices we want to collapse).
			someMesh.WeldVertices(
				// Don't collapse faces that are not smoothend together.
				WeldEpsilonsFlags.WeldPartialMatches,
				// Use the epsilon values defined above
				weldEpsilons,
				// Let WeldVertices generate the adjacency
				null);

			// Need to generate tangents because mesh doesn't provide any yet?
			if (hadTangents == false)
			{
				// Huston, we might have a problem!
				// If the vertices for a smoothend point exist several times the
				// DirectX ComputeTangent method is not able to threat them all the
				// same way (see Screenshots on my post on abi.exdream.com).
				// To circumvent this, we collapse all vertices in a cloned mesh
				// even if the texture coordinates don't fit. Then we copy the
				// generated tangents back to the original mesh vertices (duplicating
				// the tangents for vertices at the same point with the same normals
				// if required). This happens usually with models exported from 3DSMax.

				// Clone mesh just for tangent generation
				Mesh dummyTangentGenerationMesh = someMesh.Clone(
					someMesh.Options.Value,
					someMesh.Declaration,
					MainForm.DirectXDevice);

				// Reuse weldEpsilons, just change the TextureCoordinates, which we
				// don't care about anymore. TextureCoordinate expects 8 float values.
				weldEpsilons.TextureCoordinate =
					new float[] { 1, 1, 1, 1, 1, 1, 1, 1 };
				// Rest of the weldEpsilons values can stay 0, we don't use them.
				dummyTangentGenerationMesh.WeldVertices(
					// Don't collapse faces that are not smoothend together.
					WeldEpsilonsFlags.WeldPartialMatches,
					// Use the defined epsilon values
					weldEpsilons,
					// Let WeldVertices generate the adjacency
					null);

				// Compute tangents with texture channel 0,
				// tangents are in stream 0, binormals are not required
				// and wrapping doesn't help or work anyways (last 0 parameter).
				dummyTangentGenerationMesh.ComputeTangent(0, 0, D3DX.Default, 0);

				// Ok, time to copy the smoothly generated tangents back :)
				TangentVertex[] tangentVerts =
					(TangentVertex[])dummyTangentGenerationMesh.LockVertexBuffer(
					typeof(TangentVertex),
					LockFlags.None,
					new int[1] { dummyTangentGenerationMesh.NumberVertices });
				verts =
					(TangentVertex[])someMesh.LockVertexBuffer(
					typeof(TangentVertex),
					LockFlags.None,
					new int[1] { someMesh.NumberVertices });
				for (int num = 0; num < verts.Length; num++)
				{
					// Note: This check is very slow and eats up A LOT of cpu cycles.
					// If you have a lot of models consider saving the precomputed
					// tangent information in your own model format or a special file!
					// Profiler: Precalculated tangents would save up to 1 second load
					// time just for the few models in Rocket Commander. But we would
					// need our own model format, which is much work and a complex task.

					// Search for tangent vertex with the exact same position and normal.
					for (int tangentVertexNum = 0; tangentVertexNum <
						tangentVerts.Length; tangentVertexNum++)
						if (verts[num].pos == tangentVerts[tangentVertexNum].pos &&
							verts[num].normal == tangentVerts[tangentVertexNum].normal)
						{
							// Copy the tangent over
							verts[num].tangent = tangentVerts[tangentVertexNum].tangent;
							// No more checks required, proceed with next vertex
							break;
						} // for if (verts[num].pos)
				} // for (num)
				someMesh.UnlockVertexBuffer();
				dummyTangentGenerationMesh.UnlockVertexBuffer();
			} // if (hadTangents)

			// Finally optimize the mesh for the current graphics cards vertex cache.
			int[] adj = someMesh.ConvertPointRepsToAdjacency((GraphicsStream)null);
			someMesh.OptimizeInPlace(MeshFlags.OptimizeVertexCache, adj);
		} // GenerateNormalsAndTangentsIfNotPresent(someMesh)
		#endregion

		#region Calc render matrix (for calling Render)
		/// <summary>
		/// Calc default render matrix
		/// </summary>
		public static Matrix CalcDefaultRenderMatrix(Vector3 renderPos)
		{
			return Matrix.Translation(renderPos);
		} // CalcDefaultRenderMatrix(renderPos)

		/// <summary>
		/// Calc default render matrix
		/// </summary>
		public static Matrix CalcDefaultRenderMatrix(
			Vector3 renderPos, float scale)
		{
			return Matrix.Scaling(new Vector3(scale, scale, scale)) *
				Matrix.Translation(renderPos);
		} // CalcDefaultRenderMatrix(renderPos, scale)

		/// <summary>
		/// Calc default render matrix
		/// </summary>
		public static Matrix CalcDefaultRenderMatrix(
			Vector3 renderPos, float scale, float rotation)
		{
			return Matrix.Scaling(new Vector3(scale, scale, scale)) *
				// Use always a ccw rotation of 90 degrees to show model pointing up
				Matrix.RotationZ(rotation - (float)Math.PI / 2.0f) *
				Matrix.Translation(renderPos);
		} // CalcDefaultRenderMatrix(renderPos, scale, rotation)

		/// <summary>
		/// Calc default render matrix, 
		/// </summary>
		public static Matrix CalcDefaultRenderMatrix(
			Vector3 renderPos, float scale,
			float rotation, float pitch)
		{
			return
				Matrix.Scaling(new Vector3(scale, scale, scale)) *
				Matrix.RotationX(pitch) *
				Matrix.RotationZ(rotation - (float)Math.PI / 2.0f) *
				Matrix.Translation(renderPos);
		} // CalcDefaultRenderMatrix(renderPos, scale, rotation)
		#endregion

		#region Rendering
		/// <summary>
		/// Render model with specified matrix.
		/// Note: Only used for testing, etc.
		/// AsteroidManager handles own model rendering for asteroids.
		/// </summary>
		/// <param name="renderMatrix">Render matrix</param>
		public virtual void Render(Matrix renderMatrix)
		{
			// Don't render if anything is invalid
			if (Valid == false)
				return;

			// Just render all materials with or without shaders.
			// Note: It is much faster to render all models sorted by
			// materials and shaders (first shaders, then materials).
			// Since we only use 1 shader and only 1 material per object,
			// we just sort by models and just render them :)
			if (materials != null)
			{
				Matrix worldMatrix = objectMatrix * renderMatrix;

				for (int matNum = 0; matNum < materials.Length; matNum++)
				{
          /*
					if (GraphicForm.ParallaxShader.Valid)
					{
						// Try sections are free in .NET 2.0, this doesn't hurt
						// performance. And this is the most inner loop we have in this
						// game. We want to catch any errors and handle them right here.
						try
						{
							// Only update world and material parameters,
							// rest is done in GraphicForm class.
							//shader.UpdateWorldMatrix(worldMatrix);
							//shader.UpdateMaterialParameters(materials[matNum]);
							GraphicForm.ParallaxShader.WorldMatrix = worldMatrix;
							GraphicForm.ParallaxShader.UpdateMatricesAndEffectParameters();
							GraphicForm.ParallaxShader.UpdateMaterialParameters(
								materials[matNum]);

							Effect effect = GraphicForm.ParallaxShader.D3DEffect;
							try
							{
								// We only got 1 pass in ParallaxShader, but if someone
								// changes that, we also support multiple passes!
								int passes = effect.Begin(FX.None);
								for (int pass = 0; pass < passes; pass++)
								{
									effect.BeginPass(pass);
									d3dMesh.DrawSubset(matNum);
									effect.EndPass();
								} // for (pass)
							} // try
							finally
							{
								effect.End();
							} // finally
						} // try
						catch (Exception ex)
						{
							Console.WriteLine("Failed to render material " +
								(matNum < materials.Length &&
								materials[matNum] != null &&
								materials[matNum].diffuseTexture != null ?
								materials[matNum].diffuseTexture.ToString() :
								"(invalid index)") +
								" with shader: " + ex.ToString());

							// Disable shader and keep rendering without shaders.
							GraphicForm.ParallaxShader.SetEffectInvalid();
						} // catch
					} // if (materials[matNum].UsedShader)

					// No shader used or just failed, use fixed function pipeline
					// rendering (not that pretty, but at least it works everywhere).
					if (GraphicForm.ParallaxShader.Valid == false)
					{
            */

						MainForm.WorldMatrix = worldMatrix;
						materials[matNum].SelectWithoutShader();

						d3dMesh.DrawSubset(matNum);
					//} // if
				} // for (matNum)
			} // if (materials)
		} // Render(renderMatrix)

    public virtual void RenderOpacity(Matrix renderMatrix, float opacity)
    {
      if (Valid == false)
        return;

      if (materials != null)
      {
        Matrix worldMatrix = objectMatrix * renderMatrix;

        for (int matNum = 0; matNum < materials.Length; matNum++)
        {
          MainForm.WorldMatrix = worldMatrix;

          //materials[matNum].d3dMaterial.Ambient = Color.FromArgb((int)(opacity * 255), Color.White);
          materials[matNum].d3dMaterial.Diffuse = Color.FromArgb((int)(opacity * 255), Material.DefaultDiffuseColor);
          //materials[matNum].d3dMaterial.Specular = Color.FromArgb((int)(opacity * 255), Color.White);

          MainForm.DirectXDevice.Material = materials[matNum].d3dMaterial;
          
          //MainForm.DirectXDevice.SetTexture(0, materials[matNum].diffuseTexture.D3DTexture);

          materials[matNum].SelectWithoutShader();   
          
          d3dMesh.DrawSubset(matNum);

          materials[matNum].d3dMaterial.Diffuse = Color.FromArgb(255, Material.DefaultDiffuseColor);
        }
      }
    }

    public virtual void Render(Matrix renderMatrix, Color [] lighting)
    {
      if (Valid == false)
        return;

      if (materials != null)
      {
        Matrix worldMatrix = objectMatrix * renderMatrix;

        for (int matNum = 0; matNum < materials.Length; matNum++)
        {
          MainForm.WorldMatrix = worldMatrix;

          materials[matNum].d3dMaterial.Ambient = Color.FromArgb(255, lighting[0]);
          materials[matNum].d3dMaterial.Diffuse = Color.FromArgb(255, lighting[1]);
          materials[matNum].d3dMaterial.Specular = Color.FromArgb(255, lighting[2]);

          MainForm.DirectXDevice.Material = materials[matNum].d3dMaterial;
          
          //MainForm.DirectXDevice.SetTexture(0, materials[matNum].diffuseTexture.D3DTexture);

          materials[matNum].SelectWithoutShader();   
          
          d3dMesh.DrawSubset(matNum);

          materials[matNum].d3dMaterial.Ambient = Color.FromArgb(255, Material.DefaultAmbientColor);
          materials[matNum].d3dMaterial.Diffuse = Color.FromArgb(255, Material.DefaultDiffuseColor);
          materials[matNum].d3dMaterial.Specular = Color.FromArgb(255, Material.DefaultSpecularColor);
        }
      }
    }

    public virtual void RenderOpacity(Matrix renderMatrix, float opacity, Color [] lighting)
    {
      if (Valid == false)
        return;

      if (materials != null)
      {
        Matrix worldMatrix = objectMatrix * renderMatrix;

        for (int matNum = 0; matNum < materials.Length; matNum++)
        {
          MainForm.WorldMatrix = worldMatrix;

          materials[matNum].d3dMaterial.Ambient = Color.FromArgb(255, lighting[0]);
          materials[matNum].d3dMaterial.Diffuse = Color.FromArgb((int)(opacity * 255), lighting[1]);
          materials[matNum].d3dMaterial.Specular = Color.FromArgb(255, lighting[2]);

          MainForm.DirectXDevice.Material = materials[matNum].d3dMaterial;
          
          //MainForm.DirectXDevice.SetTexture(0, materials[matNum].diffuseTexture.D3DTexture);

          materials[matNum].SelectWithoutShader();   
          
          d3dMesh.DrawSubset(matNum);

          materials[matNum].d3dMaterial.Ambient = Color.FromArgb(255, Material.DefaultAmbientColor);
          materials[matNum].d3dMaterial.Diffuse = Color.FromArgb(255, Material.DefaultDiffuseColor);
          materials[matNum].d3dMaterial.Specular = Color.FromArgb(255, Material.DefaultSpecularColor);
        }
      }
    }

		/// <summary>
		/// Render model at specified position.
		/// </summary>
		public void Render(Vector3 renderPos)
		{
			Render(CalcDefaultRenderMatrix(renderPos));
		} // Render(renderPos)

		/// <summary>
		/// Render model at specified position with specified scale.
		/// </summary>
		public void Render(Vector3 renderPos, float scale)
		{
			Render(CalcDefaultRenderMatrix(renderPos, scale));
		} // Render(renderPos, scale)

		/// <summary>
		/// Render model at specified position, scale and rotation.
		/// </summary>
		public void Render(Vector3 renderPos, float scale, float rotation)
		{
			Render(CalcDefaultRenderMatrix(renderPos, scale, rotation));
		} // Render(renderPos, scale, rotation)

		/// <summary>
		/// Render model at specified position, scale, rotation and pitch.
		/// </summary>
		public void Render(Vector3 renderPos, float scale, float rotation,
			float pitch)
		{
			Render(CalcDefaultRenderMatrix(renderPos, scale, rotation, pitch));
		} // Render(renderPos, scale, rotation)
		#endregion
	} // class Model
} // namespace RocketCommander.Graphics
