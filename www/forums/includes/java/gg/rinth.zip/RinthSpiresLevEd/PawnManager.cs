using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace RinthSpires
{
	/// <summary>
	/// Summary description for PawnManager.
	/// </summary>
	public class PawnManager : System.Windows.Forms.Form
	{
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox Text_Basemodel;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.ListBox List_Animations;
    private System.Windows.Forms.TextBox Text_Model;
    private System.Windows.Forms.ListBox List_Models;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Button Button_DeleteAnimation;
    private System.Windows.Forms.Button Button_DeleteModel;
    private System.Windows.Forms.Button Button_MoveUp;
    private System.Windows.Forms.Button Button_AddAnimation;
    private System.Windows.Forms.TextBox Text_Animation;
    private System.Windows.Forms.Button Button_AddModel;
    private System.Windows.Forms.Button Button_Save;
    private System.Windows.Forms.Button Button_Cancel;
    private System.Windows.Forms.GroupBox Group_Animation;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.TextBox Text_Class;
    private System.Windows.Forms.TextBox Text_Width;
    private System.Windows.Forms.Label label7;
    private System.Windows.Forms.Button Button_BMAC;
    private System.Windows.Forms.TextBox Text_Height;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public PawnManager()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

      if(ToolboxForm.dummyPawn != null)
      {
        Text_Basemodel.Text = ToolboxForm.dummyPawn.baseModel;
        Text_Class.Text = ToolboxForm.dummyPawn.className;

        Text_Width.Text = Convert.ToString(ToolboxForm.dummyPawn.width);
        Text_Height.Text = Convert.ToString(ToolboxForm.dummyPawn.height);

        foreach(string modelname in ToolboxForm.dummyPawn.modelNames)
          List_Models.Items.Add(modelname);

        foreach(string animationname in ToolboxForm.dummyPawn.animations.Keys)
          List_Animations.Items.Add(animationname);         
      }
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.Text_Basemodel = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.Group_Animation = new System.Windows.Forms.GroupBox();
      this.Button_DeleteAnimation = new System.Windows.Forms.Button();
      this.Button_DeleteModel = new System.Windows.Forms.Button();
      this.label4 = new System.Windows.Forms.Label();
      this.Button_MoveUp = new System.Windows.Forms.Button();
      this.Button_AddAnimation = new System.Windows.Forms.Button();
      this.Text_Animation = new System.Windows.Forms.TextBox();
      this.Button_AddModel = new System.Windows.Forms.Button();
      this.List_Animations = new System.Windows.Forms.ListBox();
      this.Text_Model = new System.Windows.Forms.TextBox();
      this.List_Models = new System.Windows.Forms.ListBox();
      this.label2 = new System.Windows.Forms.Label();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.Text_Height = new System.Windows.Forms.TextBox();
      this.label7 = new System.Windows.Forms.Label();
      this.Text_Width = new System.Windows.Forms.TextBox();
      this.label5 = new System.Windows.Forms.Label();
      this.Button_Save = new System.Windows.Forms.Button();
      this.Button_Cancel = new System.Windows.Forms.Button();
      this.label6 = new System.Windows.Forms.Label();
      this.Text_Class = new System.Windows.Forms.TextBox();
      this.Button_BMAC = new System.Windows.Forms.Button();
      this.Group_Animation.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.SuspendLayout();
      // 
      // Text_Basemodel
      // 
      this.Text_Basemodel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.Text_Basemodel.Location = new System.Drawing.Point(8, 16);
      this.Text_Basemodel.Name = "Text_Basemodel";
      this.Text_Basemodel.Size = new System.Drawing.Size(160, 20);
      this.Text_Basemodel.TabIndex = 1;
      this.Text_Basemodel.Text = "";
      // 
      // label1
      // 
      this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.label1.Location = new System.Drawing.Point(8, 0);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(80, 16);
      this.label1.TabIndex = 27;
      this.label1.Text = "Basemodel -";
      this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
      // 
      // Group_Animation
      // 
      this.Group_Animation.Controls.Add(this.Button_DeleteAnimation);
      this.Group_Animation.Controls.Add(this.Button_DeleteModel);
      this.Group_Animation.Controls.Add(this.label4);
      this.Group_Animation.Controls.Add(this.Button_MoveUp);
      this.Group_Animation.Controls.Add(this.Button_AddAnimation);
      this.Group_Animation.Controls.Add(this.Text_Animation);
      this.Group_Animation.Controls.Add(this.Button_AddModel);
      this.Group_Animation.Controls.Add(this.List_Animations);
      this.Group_Animation.Controls.Add(this.Text_Model);
      this.Group_Animation.Controls.Add(this.List_Models);
      this.Group_Animation.Controls.Add(this.label2);
      this.Group_Animation.Location = new System.Drawing.Point(8, 184);
      this.Group_Animation.Name = "Group_Animation";
      this.Group_Animation.Size = new System.Drawing.Size(320, 200);
      this.Group_Animation.TabIndex = 4;
      this.Group_Animation.TabStop = false;
      this.Group_Animation.Text = "Animation";
      // 
      // Button_DeleteAnimation
      // 
      this.Button_DeleteAnimation.BackColor = System.Drawing.Color.Gainsboro;
      this.Button_DeleteAnimation.Location = new System.Drawing.Point(252, 160);
      this.Button_DeleteAnimation.Name = "Button_DeleteAnimation";
      this.Button_DeleteAnimation.Size = new System.Drawing.Size(64, 23);
      this.Button_DeleteAnimation.TabIndex = 8;
      this.Button_DeleteAnimation.Text = "Delete";
      // 
      // Button_DeleteModel
      // 
      this.Button_DeleteModel.BackColor = System.Drawing.Color.Gainsboro;
      this.Button_DeleteModel.Location = new System.Drawing.Point(252, 72);
      this.Button_DeleteModel.Name = "Button_DeleteModel";
      this.Button_DeleteModel.Size = new System.Drawing.Size(64, 24);
      this.Button_DeleteModel.TabIndex = 4;
      this.Button_DeleteModel.Text = "Delete";
      // 
      // label4
      // 
      this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.label4.Location = new System.Drawing.Point(156, 104);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(80, 16);
      this.label4.TabIndex = 2;
      this.label4.Text = "Animations";
      this.label4.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
      // 
      // Button_MoveUp
      // 
      this.Button_MoveUp.BackColor = System.Drawing.Color.WhiteSmoke;
      this.Button_MoveUp.Location = new System.Drawing.Point(156, 72);
      this.Button_MoveUp.Name = "Button_MoveUp";
      this.Button_MoveUp.Size = new System.Drawing.Size(56, 24);
      this.Button_MoveUp.TabIndex = 3;
      this.Button_MoveUp.Text = "Move up";
      this.Button_MoveUp.Click += new System.EventHandler(this.Button_MoveUp_Click);
      // 
      // Button_AddAnimation
      // 
      this.Button_AddAnimation.BackColor = System.Drawing.Color.White;
      this.Button_AddAnimation.Location = new System.Drawing.Point(252, 104);
      this.Button_AddAnimation.Name = "Button_AddAnimation";
      this.Button_AddAnimation.Size = new System.Drawing.Size(64, 23);
      this.Button_AddAnimation.TabIndex = 6;
      this.Button_AddAnimation.Text = "Add Blank";
      this.Button_AddAnimation.Click += new System.EventHandler(this.Button_AddAnimation_Click);
      // 
      // Text_Animation
      // 
      this.Text_Animation.Location = new System.Drawing.Point(156, 136);
      this.Text_Animation.Name = "Text_Animation";
      this.Text_Animation.Size = new System.Drawing.Size(160, 20);
      this.Text_Animation.TabIndex = 7;
      this.Text_Animation.Text = "";
      this.Text_Animation.TextChanged += new System.EventHandler(this.Text_Animation_TextChanged);
      // 
      // Button_AddModel
      // 
      this.Button_AddModel.BackColor = System.Drawing.Color.White;
      this.Button_AddModel.Location = new System.Drawing.Point(252, 16);
      this.Button_AddModel.Name = "Button_AddModel";
      this.Button_AddModel.Size = new System.Drawing.Size(64, 23);
      this.Button_AddModel.TabIndex = 1;
      this.Button_AddModel.Text = "Add Blank";
      this.Button_AddModel.Click += new System.EventHandler(this.Button_AddModel_Click);
      // 
      // List_Animations
      // 
      this.List_Animations.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.List_Animations.Location = new System.Drawing.Point(4, 104);
      this.List_Animations.Name = "List_Animations";
      this.List_Animations.Size = new System.Drawing.Size(144, 82);
      this.List_Animations.TabIndex = 5;
      this.List_Animations.SelectedIndexChanged += new System.EventHandler(this.List_Animations_SelectedIndexChanged);
      // 
      // Text_Model
      // 
      this.Text_Model.Location = new System.Drawing.Point(156, 48);
      this.Text_Model.Name = "Text_Model";
      this.Text_Model.Size = new System.Drawing.Size(160, 20);
      this.Text_Model.TabIndex = 2;
      this.Text_Model.Text = "";
      this.Text_Model.TextChanged += new System.EventHandler(this.Text_Model_TextChanged);
      // 
      // List_Models
      // 
      this.List_Models.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.List_Models.Location = new System.Drawing.Point(4, 16);
      this.List_Models.Name = "List_Models";
      this.List_Models.Size = new System.Drawing.Size(144, 82);
      this.List_Models.TabIndex = 0;
      this.List_Models.SelectedIndexChanged += new System.EventHandler(this.List_Models_SelectedIndexChanged);
      // 
      // label2
      // 
      this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.label2.Location = new System.Drawing.Point(156, 16);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(80, 16);
      this.label2.TabIndex = 39;
      this.label2.Text = "Models ";
      this.label2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
      // 
      // groupBox3
      // 
      this.groupBox3.Controls.Add(this.Text_Height);
      this.groupBox3.Controls.Add(this.label7);
      this.groupBox3.Controls.Add(this.Text_Width);
      this.groupBox3.Controls.Add(this.label5);
      this.groupBox3.Location = new System.Drawing.Point(8, 128);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(320, 48);
      this.groupBox3.TabIndex = 3;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Collision";
      // 
      // Text_Height
      // 
      this.Text_Height.AcceptsReturn = true;
      this.Text_Height.Location = new System.Drawing.Point(224, 16);
      this.Text_Height.Name = "Text_Height";
      this.Text_Height.Size = new System.Drawing.Size(32, 20);
      this.Text_Height.TabIndex = 1;
      this.Text_Height.Text = "1";
      // 
      // label7
      // 
      this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.label7.Location = new System.Drawing.Point(176, 16);
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size(48, 16);
      this.label7.TabIndex = 42;
      this.label7.Text = "Height -";
      this.label7.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
      // 
      // Text_Width
      // 
      this.Text_Width.AcceptsReturn = true;
      this.Text_Width.Location = new System.Drawing.Point(104, 16);
      this.Text_Width.Name = "Text_Width";
      this.Text_Width.Size = new System.Drawing.Size(32, 20);
      this.Text_Width.TabIndex = 0;
      this.Text_Width.Text = "1";
      // 
      // label5
      // 
      this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.label5.Location = new System.Drawing.Point(56, 16);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(48, 16);
      this.label5.TabIndex = 40;
      this.label5.Text = "Width -";
      this.label5.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
      // 
      // Button_Save
      // 
      this.Button_Save.BackColor = System.Drawing.Color.White;
      this.Button_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Button_Save.Location = new System.Drawing.Point(104, 392);
      this.Button_Save.Name = "Button_Save";
      this.Button_Save.Size = new System.Drawing.Size(224, 32);
      this.Button_Save.TabIndex = 6;
      this.Button_Save.Text = "&Save";
      this.Button_Save.Click += new System.EventHandler(this.Button_Save_Click);
      // 
      // Button_Cancel
      // 
      this.Button_Cancel.BackColor = System.Drawing.Color.Gainsboro;
      this.Button_Cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Button_Cancel.Location = new System.Drawing.Point(8, 392);
      this.Button_Cancel.Name = "Button_Cancel";
      this.Button_Cancel.Size = new System.Drawing.Size(88, 32);
      this.Button_Cancel.TabIndex = 5;
      this.Button_Cancel.Text = "&Cancel";
      this.Button_Cancel.Click += new System.EventHandler(this.Button_Cancel_Click);
      // 
      // label6
      // 
      this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.label6.Location = new System.Drawing.Point(8, 40);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(112, 16);
      this.label6.TabIndex = 34;
      this.label6.Text = "Class name -";
      this.label6.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
      // 
      // Text_Class
      // 
      this.Text_Class.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.Text_Class.Location = new System.Drawing.Point(8, 56);
      this.Text_Class.Name = "Text_Class";
      this.Text_Class.Size = new System.Drawing.Size(160, 20);
      this.Text_Class.TabIndex = 2;
      this.Text_Class.Text = "";
      // 
      // Button_BMAC
      // 
      this.Button_BMAC.BackColor = System.Drawing.Color.WhiteSmoke;
      this.Button_BMAC.Location = new System.Drawing.Point(176, 16);
      this.Button_BMAC.Name = "Button_BMAC";
      this.Button_BMAC.Size = new System.Drawing.Size(152, 20);
      this.Button_BMAC.TabIndex = 7;
      this.Button_BMAC.Text = "Basemodel and Class";
      this.Button_BMAC.Click += new System.EventHandler(this.Button_BMAC_Click);
      // 
      // PawnManager
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.BackColor = System.Drawing.Color.LightGray;
      this.ClientSize = new System.Drawing.Size(336, 427);
      this.ControlBox = false;
      this.Controls.Add(this.Button_BMAC);
      this.Controls.Add(this.label6);
      this.Controls.Add(this.Text_Class);
      this.Controls.Add(this.Text_Basemodel);
      this.Controls.Add(this.Button_Cancel);
      this.Controls.Add(this.Button_Save);
      this.Controls.Add(this.groupBox3);
      this.Controls.Add(this.Group_Animation);
      this.Controls.Add(this.label1);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
      this.Name = "PawnManager";
      this.Text = "Pawn Manager";
      this.Group_Animation.ResumeLayout(false);
      this.groupBox3.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion

    private void Button_Save_Click(object sender, System.EventArgs e)
    {
      if(GameClass.modelSource[Text_Basemodel.Text] != null)
      {
        Pawn toadd = new Pawn();

        toadd.baseModel = Text_Basemodel.Text;
        toadd.width = Convert.ToSingle(Text_Width.Text);
        toadd.height = Convert.ToSingle(Text_Height.Text);
        toadd.className = Text_Class.Text;
        
        foreach(string model in List_Models.Items)
          toadd.modelNames.Add(model);

        foreach(string anim in List_Animations.Items)
          toadd.animations.Add(anim, new ArrayList());

        //foreach(string anim in List_Animations.Items)
          //toadd.AddAnimation(anim, (anim + ".anim"));

        if(GameClass.availablePawns[Text_Basemodel.Text] != null)
          GameClass.availablePawns[Text_Basemodel.Text] = toadd.Clone();
        else
          GameClass.availablePawns.Add(Text_Basemodel.Text, toadd.Clone());

        MainForm.Toolbox.RefreshPawnList();

        this.Close();    
      }
    }

    private void Button_Cancel_Click(object sender, System.EventArgs e)
    {
      this.Close();
    }

    private void Button_AddModel_Click(object sender, System.EventArgs e)
    {
      List_Models.Items.Add("(new)");
    }

    private void Button_AddAnimation_Click(object sender, System.EventArgs e)
    {
      List_Animations.Items.Add("(new)");
    }

    private void Text_Model_TextChanged(object sender, System.EventArgs e)
    {
      if(List_Models.SelectedIndex > -1)
      {
        List_Models.Items[List_Models.SelectedIndex] = Text_Model.Text;
      }
    }

    private void Text_Animation_TextChanged(object sender, System.EventArgs e)
    {
      if(List_Animations.SelectedIndex > -1)
      {
        List_Animations.Items[List_Animations.SelectedIndex] = Text_Animation.Text;
      }
    }

    private void Button_MoveUp_Click(object sender, System.EventArgs e)
    {
      if(List_Models.SelectedIndex > 0)
      {
        int sel = List_Models.SelectedIndex;
        string temp = (string)List_Models.Items[sel - 1];
        List_Models.Items[sel - 1] = (string)List_Models.Items[sel];
        List_Models.Items[sel] = temp;
      }
    }

    private void List_Models_SelectedIndexChanged(object sender, System.EventArgs e)
    {
      if(List_Models.SelectedIndex > -1)
        Text_Model.Text = (string)List_Models.Items[List_Models.SelectedIndex];
    }

    private void List_Animations_SelectedIndexChanged(object sender, System.EventArgs e)
    {
      if(List_Animations.SelectedIndex > -1)
        Text_Animation.Text = (string)List_Animations.Items[List_Animations.SelectedIndex];
    }

    private void Button_BMAC_Click(object sender, System.EventArgs e)
    {
      Text_Class.Text = Text_Basemodel.Text;
    }
	}
}
