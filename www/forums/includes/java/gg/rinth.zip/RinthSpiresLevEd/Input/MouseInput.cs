#region Using directives
using System;
using System.Windows.Forms;
using System.Threading;
using Microsoft.DirectX.DirectInput;
#endregion

namespace RinthSpires
{
  public class MouseInput
  {
    #region Variables
    private Device mouse = null;

    private float virtualMovementX = 0;
    private float	virtualMovementY = 0;
    private float	smoothendMovementX = 0;
    private float	smoothendMovementY = 0;

    private float xMovement = 0.0f;
    private float	yMovement = 0.0f;
    private float	wheelDelta = 0.0f;


    private bool leftButtonPressed = false;
    private bool rightButtonPressed = false;
    #endregion

    #region Properties
    public float XMovement{ get{ return xMovement; } }

    public float YMovement
    {
      get
      {
        return yMovement;
      } 
    } 

    public float WheelDelta
    {
      get
      {
        return wheelDelta;
      } 
    } 

    public bool LeftButtonPressed
    {
      get
      {
        return leftButtonPressed;
      }
    } 

    public bool RightButtonPressed
    {
      get
      {
        return rightButtonPressed;
      }
    } 
    #endregion

    #region Constructor
    public MouseInput(Form form)
    {
      // Create mouse device
      mouse = new Device(SystemGuid.Mouse);

      // Allow other apps to use the mouse too, everything else would be crazy.
      mouse.SetCooperativeLevel(form,
        CooperativeLevelFlags.Background |
        CooperativeLevelFlags.NonExclusive);

      // Set the data format to the mouse2 pre-defined format.
      mouse.SetDataFormat(DeviceDataFormat.Mouse);

      // Use relative axis mode to get moving differences, for absolut mouse
      // position use the Mouse events in GameForm (using Windows events).
      mouse.Properties.AxisModeAbsolute = false;

      // Acquire mouse
      mouse.Acquire();

      // Perform the first update
      Update();
    } 
    #endregion

    #region Update
    public void Update()
    {
      // Check the mouse state
      MouseState state = mouse.CurrentMouseState;

      // Copy over data
      virtualMovementX += state.X;
      virtualMovementY += state.Y;
      wheelDelta = state.Z;

      // Slowly interpolate from current movement to virtual movement
      xMovement = xMovement * 0.75f + (virtualMovementX - smoothendMovementX) * 0.25f;
      yMovement = yMovement * 0.75f + (virtualMovementY - smoothendMovementY) * 0.25f;
      smoothendMovementX = virtualMovementX;
      smoothendMovementY = virtualMovementY;

      // Check if left or right button is pressed
      byte[] buttons = state.GetMouseButtons();
      leftButtonPressed = buttons.Length > 0 && buttons[0] != 0;
      rightButtonPressed = buttons.Length > 1 && buttons[1] != 0;
    }
    #endregion
  } 
}