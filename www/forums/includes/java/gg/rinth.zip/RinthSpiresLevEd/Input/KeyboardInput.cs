#region Using directives
using System;
using System.Windows.Forms;
using System.Threading;
using Microsoft.DirectX.DirectInput;
#endregion

namespace RinthSpires
{
  public class KeyboardInput
  {
    #region Variables
    private Device keyboard = null;
    private KeyboardState state;
    #endregion

    #region Properties
    public bool Left
    {
      get
      {
        return state != null && state[Key.LeftArrow];
      }
    }

    public bool Right
    {
      get
      {
        return state != null && state[Key.RightArrow];
      } 
    } 

    public bool Up
    {
      get
      {
        return state != null && state[Key.UpArrow];
      } 
    } 

    public bool Down
    {
      get
      {
        return state != null && state[Key.DownArrow];
      } 
    } 

    public bool Escape
    {
      get
      {
        return state != null && state[Key.Escape];
      }
    } 

    bool lastFrameEscapePressed = false;

    public bool EscapeJustPressed
    {
      get
      {
        return Escape && lastFrameEscapePressed == false;
      } 
    }

    // For example: keyboardInput.State[Key.F1] ...
    public KeyboardState State
    {
      get
      {
        return state;
      }
    }
    #endregion

    #region Constructo
    public KeyboardInput(Form form)
    {
      // Create keyboard device
      keyboard = new Device(SystemGuid.Keyboard);

      // Allow other apps to have keyboard input as well
      keyboard.SetCooperativeLevel(form, CooperativeLevelFlags.Background | CooperativeLevelFlags.NonExclusive);

      // Acquire keyboard
      keyboard.Acquire();
    } 
    #endregion

    #region Update
    public void Update()
    {
      // Remember state from last frame
      lastFrameEscapePressed = Escape;

      // Check the keyboard state
      state = keyboard.GetCurrentKeyboardState();
    } 
    #endregion
  } 
} 