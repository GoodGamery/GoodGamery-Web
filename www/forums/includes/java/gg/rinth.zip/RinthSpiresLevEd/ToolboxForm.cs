using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace RinthSpires
{
	/// <summary>
	/// Summary description for ToolboxForm.
	/// </summary>
	public class ToolboxForm : System.Windows.Forms.Form
	{
    private System.Windows.Forms.MainMenu mainMenu1;
    private System.Windows.Forms.MenuItem menuItem1;
    private System.Windows.Forms.MenuItem menuItem2;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Button Button_DeletePawn;
    private System.Windows.Forms.Button Button_EditPawn;
    private System.Windows.Forms.Button Button_AddPawn;


    public PawnManager pawnManager = null;
    private System.Windows.Forms.MenuItem menuItem3;
    private System.Windows.Forms.MenuItem menuItem4;

    public static Pawn dummyPawn = null;
    public static string dummyName = "";
    private System.Windows.Forms.ListBox List_Towers;
    public System.Windows.Forms.ListBox List_Pawns;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.Label label7;
    private System.Windows.Forms.Label label8;
    private System.Windows.Forms.MenuItem menuItem5;
    private System.Windows.Forms.MenuItem menuItem6;
    private System.Windows.Forms.Label label9;
    private System.Windows.Forms.Label label10;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ToolboxForm()
		{
      this.Location = new Point(80, 100);

			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//

      List_Towers.Items.Add("Floating Beach");
      List_Towers.Items.Add("Hollow Deep");
      List_Towers.Items.Add("Ancient Garden");
      List_Towers.Items.Add("Forgotten Grove");
      List_Towers.Items.Add("Dust Factory");
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.mainMenu1 = new System.Windows.Forms.MainMenu();
      this.menuItem1 = new System.Windows.Forms.MenuItem();
      this.menuItem5 = new System.Windows.Forms.MenuItem();
      this.menuItem6 = new System.Windows.Forms.MenuItem();
      this.menuItem3 = new System.Windows.Forms.MenuItem();
      this.menuItem4 = new System.Windows.Forms.MenuItem();
      this.menuItem2 = new System.Windows.Forms.MenuItem();
      this.List_Pawns = new System.Windows.Forms.ListBox();
      this.label1 = new System.Windows.Forms.Label();
      this.List_Towers = new System.Windows.Forms.ListBox();
      this.label2 = new System.Windows.Forms.Label();
      this.Button_DeletePawn = new System.Windows.Forms.Button();
      this.Button_EditPawn = new System.Windows.Forms.Button();
      this.Button_AddPawn = new System.Windows.Forms.Button();
      this.panel1 = new System.Windows.Forms.Panel();
      this.label8 = new System.Windows.Forms.Label();
      this.label7 = new System.Windows.Forms.Label();
      this.label6 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.label9 = new System.Windows.Forms.Label();
      this.label10 = new System.Windows.Forms.Label();
      this.panel1.SuspendLayout();
      this.SuspendLayout();
      // 
      // mainMenu1
      // 
      this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.menuItem1});
      // 
      // menuItem1
      // 
      this.menuItem1.Index = 0;
      this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.menuItem5,
                                                                              this.menuItem6,
                                                                              this.menuItem3,
                                                                              this.menuItem4,
                                                                              this.menuItem2});
      this.menuItem1.Text = "&File";
      // 
      // menuItem5
      // 
      this.menuItem5.Index = 0;
      this.menuItem5.Text = "&Load";
      this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click);
      // 
      // menuItem6
      // 
      this.menuItem6.Index = 1;
      this.menuItem6.Text = "-";
      // 
      // menuItem3
      // 
      this.menuItem3.Enabled = false;
      this.menuItem3.Index = 2;
      this.menuItem3.Text = "&Save";
      this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
      // 
      // menuItem4
      // 
      this.menuItem4.Index = 3;
      this.menuItem4.Text = "-";
      // 
      // menuItem2
      // 
      this.menuItem2.Index = 4;
      this.menuItem2.Text = "&Exit";
      this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
      // 
      // List_Pawns
      // 
      this.List_Pawns.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.List_Pawns.Location = new System.Drawing.Point(8, 104);
      this.List_Pawns.Name = "List_Pawns";
      this.List_Pawns.ScrollAlwaysVisible = true;
      this.List_Pawns.Size = new System.Drawing.Size(256, 264);
      this.List_Pawns.TabIndex = 1;
      this.List_Pawns.SelectedIndexChanged += new System.EventHandler(this.List_Pawns_SelectedIndexChanged);
      // 
      // label1
      // 
      this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.label1.Location = new System.Drawing.Point(8, 0);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(112, 16);
      this.label1.TabIndex = 6;
      this.label1.Text = "Tower -";
      this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
      // 
      // List_Towers
      // 
      this.List_Towers.Location = new System.Drawing.Point(8, 16);
      this.List_Towers.Name = "List_Towers";
      this.List_Towers.Size = new System.Drawing.Size(256, 69);
      this.List_Towers.TabIndex = 12;
      this.List_Towers.SelectedIndexChanged += new System.EventHandler(this.List_Towers_SelectedIndexChanged);
      // 
      // label2
      // 
      this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.label2.Location = new System.Drawing.Point(8, 88);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(176, 16);
      this.label2.TabIndex = 21;
      this.label2.Text = "Available objects -";
      this.label2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
      // 
      // Button_DeletePawn
      // 
      this.Button_DeletePawn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.Button_DeletePawn.BackColor = System.Drawing.Color.Gainsboro;
      this.Button_DeletePawn.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Button_DeletePawn.Location = new System.Drawing.Point(264, 152);
      this.Button_DeletePawn.Name = "Button_DeletePawn";
      this.Button_DeletePawn.Size = new System.Drawing.Size(24, 16);
      this.Button_DeletePawn.TabIndex = 24;
      this.Button_DeletePawn.Text = "-";
      // 
      // Button_EditPawn
      // 
      this.Button_EditPawn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.Button_EditPawn.BackColor = System.Drawing.Color.WhiteSmoke;
      this.Button_EditPawn.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Button_EditPawn.Location = new System.Drawing.Point(264, 128);
      this.Button_EditPawn.Name = "Button_EditPawn";
      this.Button_EditPawn.Size = new System.Drawing.Size(24, 24);
      this.Button_EditPawn.TabIndex = 23;
      this.Button_EditPawn.Text = "e";
      this.Button_EditPawn.Click += new System.EventHandler(this.Button_EditPawn_Click);
      // 
      // Button_AddPawn
      // 
      this.Button_AddPawn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.Button_AddPawn.BackColor = System.Drawing.Color.White;
      this.Button_AddPawn.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Button_AddPawn.Location = new System.Drawing.Point(264, 104);
      this.Button_AddPawn.Name = "Button_AddPawn";
      this.Button_AddPawn.Size = new System.Drawing.Size(24, 24);
      this.Button_AddPawn.TabIndex = 22;
      this.Button_AddPawn.Text = "+";
      this.Button_AddPawn.Click += new System.EventHandler(this.Button_AddPawn_Click);
      // 
      // panel1
      // 
      this.panel1.BackColor = System.Drawing.Color.WhiteSmoke;
      this.panel1.Controls.Add(this.label10);
      this.panel1.Controls.Add(this.label9);
      this.panel1.Controls.Add(this.label8);
      this.panel1.Controls.Add(this.label7);
      this.panel1.Controls.Add(this.label6);
      this.panel1.Controls.Add(this.label5);
      this.panel1.Controls.Add(this.label4);
      this.panel1.Controls.Add(this.label3);
      this.panel1.Location = new System.Drawing.Point(8, 376);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(276, 170);
      this.panel1.TabIndex = 25;
      // 
      // label8
      // 
      this.label8.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.label8.Location = new System.Drawing.Point(0, 80);
      this.label8.Name = "label8";
      this.label8.Size = new System.Drawing.Size(224, 16);
      this.label8.TabIndex = 5;
      this.label8.Text = "[SPACE] Clear Row and Make Floor";
      // 
      // label7
      // 
      this.label7.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.label7.Location = new System.Drawing.Point(0, 0);
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size(144, 16);
      this.label7.TabIndex = 4;
      this.label7.Text = "[ARROWS] Move Cursor";
      // 
      // label6
      // 
      this.label6.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.label6.Location = new System.Drawing.Point(0, 40);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(128, 16);
      this.label6.TabIndex = 3;
      this.label6.Text = "[S] Next Object";
      // 
      // label5
      // 
      this.label5.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.label5.Location = new System.Drawing.Point(0, 24);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(128, 16);
      this.label5.TabIndex = 2;
      this.label5.Text = "[W] Previous Object";
      // 
      // label4
      // 
      this.label4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.label4.Location = new System.Drawing.Point(0, 104);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(128, 16);
      this.label4.TabIndex = 1;
      this.label4.Text = "[A] Clear Slot";
      // 
      // label3
      // 
      this.label3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.label3.Location = new System.Drawing.Point(0, 64);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(128, 16);
      this.label3.TabIndex = 0;
      this.label3.Text = "[D] Place Object";
      // 
      // label9
      // 
      this.label9.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.label9.Location = new System.Drawing.Point(0, 128);
      this.label9.Name = "label9";
      this.label9.Size = new System.Drawing.Size(128, 16);
      this.label9.TabIndex = 6;
      this.label9.Text = "[Q] Rotate CCW";
      // 
      // label10
      // 
      this.label10.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.label10.Location = new System.Drawing.Point(0, 144);
      this.label10.Name = "label10";
      this.label10.Size = new System.Drawing.Size(128, 16);
      this.label10.TabIndex = 7;
      this.label10.Text = "[E] Rotate CCW";
      // 
      // ToolboxForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.BackColor = System.Drawing.Color.Silver;
      this.ClientSize = new System.Drawing.Size(292, 613);
      this.Controls.Add(this.panel1);
      this.Controls.Add(this.Button_DeletePawn);
      this.Controls.Add(this.Button_EditPawn);
      this.Controls.Add(this.Button_AddPawn);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.List_Towers);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.List_Pawns);
      this.Menu = this.mainMenu1;
      this.MinimumSize = new System.Drawing.Size(300, 640);
      this.Name = "ToolboxForm";
      this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
      this.Text = "ToolboxForm";
      this.Load += new System.EventHandler(this.ToolboxForm_Load);
      this.Closed += new System.EventHandler(this.ToolboxForm_Closed);
      this.panel1.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion

    public void RefreshPawnList()
    {
      int sel = List_Pawns.SelectedIndex;
    
      List_Pawns.Items.Clear();

      foreach(string pawnname in GameClass.availablePawns.GetKeyList())
        List_Pawns.Items.Add(pawnname);

      List_Pawns.SelectedIndex = sel;
    }

    private void menuItem2_Click(object sender, System.EventArgs e)
    {
      this.Close();
    }

    private void ToolboxForm_Closed(object sender, System.EventArgs e)
    {
      MainForm.bailout = true;
    }

    private void ToolboxForm_Load(object sender, System.EventArgs e)
    {
    
    }

    private void groupBox1_Enter(object sender, System.EventArgs e)
    {
    
    }

    private void Button_AddPawn_Click(object sender, System.EventArgs e)
    {
      dummyPawn = null;

      if(pawnManager != null)
        pawnManager.Close();

      pawnManager = new PawnManager();
      pawnManager.Show();
    }

    private void Button_EditPawn_Click(object sender, System.EventArgs e)
    {
      int sel = List_Pawns.SelectedIndex;

      dummyPawn = null;

      if(sel > -1)
      {
        dummyName = ((string)List_Pawns.Items[sel]);
        dummyPawn = (Pawn)(((Pawn)GameClass.availablePawns[dummyName]).Clone());

        if(pawnManager != null)
          pawnManager.Close();

        pawnManager = new PawnManager();
        pawnManager.Show();
      }      
    }

    private void List_Pawns_SelectedIndexChanged(object sender, System.EventArgs e)
    {
      int sel = List_Pawns.SelectedIndex;

      if(sel > -1)
      {
        GameClass.selected = null;

        string dummyName = ((string)List_Pawns.Items[sel]);
        GameClass.selected = new Pawn(((Pawn)GameClass.availablePawns[dummyName]).baseModel);
      }
    }

    private void menuItem3_Click(object sender, System.EventArgs e)
    {
      GameClass.SaveOut();
    }

    private void menuItem5_Click(object sender, System.EventArgs e)
    {
      GameClass.LoadIn();
      menuItem3.Enabled = true;
    }

    private void List_Towers_SelectedIndexChanged(object sender, System.EventArgs e)
    {
      int sel = List_Towers.SelectedIndex;

      if(sel > -1)
      {
        GameClass.LoadLevel(sel);
      }
    }
	}
}
