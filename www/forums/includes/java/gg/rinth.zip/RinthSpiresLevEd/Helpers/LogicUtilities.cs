#region Using
using System;
using System.Collections;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.Threading;
using System.ComponentModel;
using System.Data;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using Microsoft.DirectX.DirectInput;
#endregion

namespace RinthSpires
{
  public class Util
  {
    public static bool AlmostEqual(float a, float b, float give)
    {     
      if(a >= b - (give / 2) && a <= b + (give / 2))
        return true;

      return false;
    }

    // Wraps if beyond a range of 0 to max, including 0 and max
    public static void Wrap(ref float initial, float max)
    {
      if(initial > max)
        initial -= max;
      else if(initial < 0)
        initial += max;
    }

    // Wraps if beyond a range of 0 to max, including 0 and excluding max
    public static void WrapExclusive(ref float initial, float max)
    {
      if(initial >= max)
        initial -= max;
      else if(initial < 0)
        initial += max;
    }

    public static void Wrap(ref int initial, int max)
    {
      if(initial > max)
        initial -= max;
      else if(initial < 0)
        initial += max;
    }
  }

  public class Task
  {
    float goal = 0;
    float mps = 0;
    float wrap = 0;

    public Task()
    {}

    public Task(float fGoal, float fMPS, float fWrap)
    {
      goal = fGoal;
      mps = fMPS;
      wrap = fWrap;

      if(wrap > 0)
      {
        Util.Wrap(ref goal, wrap);
      }
    }

    public bool Progress(ref float amount, float delta)
    {
      amount += mps * delta;

      if(goal > 0 && goal < wrap)
      {
        if(wrap > 0)
        {
          Util.WrapExclusive(ref amount, wrap);
        }
      }

      if(mps > 0) // Positive move
      {
        if(amount >= goal)
        {
          amount = goal;

          if(amount == wrap)
            amount = 0;

          return true;
        }
      }
      else // Negative move
      {
        if(amount <= goal)
        {
          amount = goal;

          if(amount == wrap)
            amount = 0;

          return true;
        }
      }

      return false;
    }
  }
}