#region Using directives
using System;
using System.Collections;
using System.Text;
using System.Threading;
#endregion

namespace RinthSpires
{
  public class ElapsedTime
  {
    #region Variables
    private static long startTimeNs = WindowsHelper.ConvertToNs(WindowsHelper.GetPerformanceCounter());
    private static long lastTimeNs = 0;
    private static long elapsedTimeNs = 0;
    private static int elapsedTimeLastFrameNs = 1000;
    private static int elapsedTimeLastFrameMs = 1;

    private static long startTimeThisSecond = 0;

    private static int frameCountThisSecond = 0;
    private static int totalFrameCount = 0;
    private static int fpsLastSecond = 1;
    #endregion

    #region Public properties to get ms, ns and fps
    public static long NsLastFrame
    {
      get
      {
        return elapsedTimeLastFrameNs;
      } 
    } 

    public static long NsTotal
    {
      get
      {
        return elapsedTimeNs;
      }
    }

    public static int MsLastFrame
    {
      get
      {
        return elapsedTimeLastFrameMs;
      } 
    }

    public static int MsTotal
    {
      get
      {
        return (int)(elapsedTimeNs / 1000);
      } 
    } 

    public static int FramesPerSecond
    {
      get
      {
        if (fpsLastSecond <= 0)
          return 1;
        return fpsLastSecond;
      } 
    }

    public static int TotalFrames
    {
      get
      {
        return totalFrameCount;
      } 
    } 

    /// <summary>
    /// Move factor per second, when we got 1 fps, this will be 1.0f,
    /// when we got 100 fps, this will be 0.01f.
    /// Very useful for physics and movement, this way we can easily
    /// make objects move at specific speed not frame rate dependend.
    /// Note: For multithreaded physics you don't need this!
    /// </summary>
    public static float MoveFactorPerSecond
    {
      get
      {
        return elapsedTimeLastFrameNs / 1000000.0f;
      } 
    }
    #endregion

    #region Update all values, should be called each frame
    public static void Update()
    {
      // Get current time in ns
      long currentTimeNs = (long)(WindowsHelper.GetPerformanceCounter() * 1000000 / WindowsHelper.GetPerformanceFrequency());
      // If lastTimeNs is unused, just set it startTime.
      if (lastTimeNs == 0)
      {
        // Use start time
        lastTimeNs = startTimeNs;
        // If difference is too high cap at 100ms.
        // This is much better than to use any very high value due the
        // application startup process (which can be several seconds).
        if (currentTimeNs - lastTimeNs > 100000)
          lastTimeNs = currentTimeNs - 100000;
      } 

      // Real time elapsed since last tick time
      elapsedTimeLastFrameNs = (int)(currentTimeNs - lastTimeNs);

      // We never miss any ms that elapses, we use percission of ns!
      // This means even if we got updates smaller than a ms (e.g. 300ns),
      // we will maybe get some updateMs with 0, but then we get an updateMs
      // with 1. This wont happen on normal computers, but anyway
      // we need this percision for high performance anyway (e.g. update
      // with 1900ns to time with 200ns should result in 2ms update and
      // not in 1ms (=1900ns/1000)!)
      elapsedTimeLastFrameMs = (int)(((elapsedTimeNs + elapsedTimeLastFrameNs) / 1000) - (elapsedTimeNs / 1000));

      // Only increase lastTimeNs by smoothendElapsedLastFrameTimeNs
      // to make sure we never miss any ns!
      lastTimeNs += elapsedTimeLastFrameNs;

      // Same for elapsed time (should be in sync with
      // elapsed time last frame)
      elapsedTimeNs += elapsedTimeLastFrameNs;

      // Increase frame counter for FramesPerSecond
      frameCountThisSecond++;
      totalFrameCount++;

      // One second elapsed?
      if (Math.Abs((int)(currentTimeNs - startTimeThisSecond)) > 1000000)
      {
        // Calc fps
        fpsLastSecond = (int)((float)(frameCountThisSecond * 1000000) / (currentTimeNs - startTimeThisSecond));
        // Reset startSecondTick and repaintCountSecond
        startTimeThisSecond = currentTimeNs;
        frameCountThisSecond = 0;
      } 
    } 
    #endregion
  }	
} 
