#region Using
using System;
using System.Collections;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.Threading;
using System.ComponentModel;
using System.Data;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using System.Runtime.InteropServices;
#endregion

namespace RinthSpires
{
  public class MainForm : System.Windows.Forms.Form
  {
    static MainForm form = null;

    public static StreamWriter fileout = null;

    #region MAIN

    [STAThread]
    public static void Main() 
    {
      fileout = new StreamWriter("C:\\rinthlog.txt", false);

      form = new MainForm();
    }

    public void MainLoop()
    {
      Application.EnableVisualStyles();
      Application.Idle += new EventHandler(OnApplicationIdle);

      Application.Run(form);

      this.Close();
    }

    private void OnApplicationIdle(object sender, EventArgs e)
    {
      while (AppStillIdle && !bailout)
      {
        UpdateLoop();
      }

      if(bailout)
      {
        if(fileout != null)
        {
          fileout.Close();
          fileout = null;
        }

        this.Close();
      }
    }
  
    private bool AppStillIdle
    {
      get
      {
        NativeMethods.Message msg;
        return !NativeMethods.PeekMessage(out msg, IntPtr.Zero, 0, 0, 0);
      }
    }

    #endregion

    #region Variables
    public static Device device = null;
    public GameClass game = null;
    public Rectangle resolutionRect;
    public Size resolution;
    public PresentParameters presentParams = null;

    public static ToolboxForm toolbox;

    public static ToolboxForm Toolbox
    {
      get
      {
        return toolbox;
      }
    }

    public static Device DirectXDevice
    {
      get
      {
        return device;
      }
    }

    //protected MusicManager music;
    private static KeyboardInput keyboardInput;
    private static MouseInput mouseInput;
    private static Point mousePos;
    //public SpaceCamera camera = new SpaceCamera(new Vector3(0, 0, -5));

    

    #region Flags
    public bool isNotClosed = true;   
    public bool fullscreen = false;
    public bool readyToDraw = false;
    public bool isDeviceLost = false;
    public static bool bailout = false;
    public static bool holdup = false;
    public bool isActive = true;
    #endregion

    #region Promise Flags
    bool promiseBuildProjectionMatrix = false;
    #endregion

    #region Matrices
    public static float aspectRatio;
    public static float fieldOfView;
    public static float nearPlane;
    public static float farPlane;

    private static Matrix worldMatrix;
    private static Matrix viewMatrix;
    private static Matrix projectionMatrix;
    private System.Windows.Forms.Timer timer1;
    private System.ComponentModel.IContainer components;
    private static Matrix viewProjMatrix;
    #endregion  

    #region Properties
    public Matrix ProjectionMatrix
    {
      get
      {
        return projectionMatrix;
      } 
      set
      {
        projectionMatrix = value;
        device.Transform.Projection = projectionMatrix;
      } 
    } 

    public Matrix ViewMatrix
    {
      get
      {
        return viewMatrix;
      } 
      set
      {
        viewMatrix = value;
        viewProjMatrix = viewMatrix * projectionMatrix;
        device.Transform.View = viewMatrix;
      } 
    } 

    public static Matrix WorldMatrix
    {
      get
      {
        return worldMatrix;
      }
      set
      {
        if (worldMatrix != value)
        {
          worldMatrix = value;
          device.Transform.World = worldMatrix;
        } 
      } 
    }

    public static Matrix InverseViewMatrix
    {
      get
      {
        return Matrix.Invert(viewMatrix);
      }
    }

    public static Vector3 CameraPos
    {
      get
      {
        Matrix invView = InverseViewMatrix;
        return new Vector3(invView.M41, invView.M42, invView.M43);
      }
    }
    #endregion
    #endregion

    #region Properties
    public static KeyboardInput Keyboard {get{return keyboardInput;}}
    public static MouseInput Mouse {get{return mouseInput;}}
    public new static Point MousePosition {get{return mousePos;}}
    #endregion

    #region Contructor
    public MainForm()
    {
      this.Location = new Point(380, 100);
      
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      InitializeDirectX();

      //-=-=-=-=-


      resolutionRect = new Rectangle(Point.Empty, resolution);

      //--music = new MusicManager();

      // Initialize Sound for all samples we will use in this game
      //--Sound.Init(this);

      // Init keyboard and mouse with DirectInput
      keyboardInput = new KeyboardInput(this);
      mouseInput = new MouseInput(this);

      ViewMatrix = Matrix.LookAtLH(
        new Vector3(0.0f, 10.0f, -420.0f),
        new Vector3(0.0f, 0.0f, 0.0f),
        new Vector3(0.0f, 1.0f, 0.0f));

      aspectRatio = (float)this.ClientSize.Width / (float)this.ClientSize.Height;
      fieldOfView = (float)Math.PI / 4.0f;
      nearPlane = 4.0f;
      farPlane = 500.0f;

      device.Transform.Projection = Matrix.PerspectiveFovLH(fieldOfView, aspectRatio, nearPlane, farPlane);

      this.Show();
   
      game = new GameClass();

      readyToDraw = game.LoadResources();

      OnResetDevice(device, null);

      promiseBuildProjectionMatrix = true;

      toolbox = new ToolboxForm();
      toolbox.Show();

      MainLoop();
    }
    #endregion  

    #region Initialize DirectX, shaders, events, etc.

    protected void InitializeDirectX()
    {

      fullscreen = false;
      resolution = this.ClientSize;

      // Setup DirectX device
      presentParams = new PresentParameters();

      // Always use windowed mode for debugging and fullscreen for.
      presentParams.Windowed = true;


      presentParams.PresentationInterval = PresentInterval.Default;
      presentParams.BackBufferFormat = Format.X8R8G8B8;
      presentParams.BackBufferWidth = resolution.Width;
      presentParams.BackBufferHeight = resolution.Height;

      // Default to triple buffering for performance gain,
      // if we are low on video memory and use multisampling, 1 is ok too.
      presentParams.BackBufferCount = 2;

      
      // Discard back buffer when swapping, its faster
      presentParams.SwapEffect = SwapEffect.Discard;


      // Use a Z-Buffer with 32 bit if possible
      presentParams.EnableAutoDepthStencil = true;
      presentParams.AutoDepthStencilFormat = DepthFormat.D24X8;//D32;

      //presentParams.MultiSample = MultiSampleType.TwoSamples;
      //presentParams.MultiSampleQuality = 2;
  

      // For windowed, default to PresentInterval.Immediate which will
      // wait not for the vertical retrace period to prevent tearing,
      // but may introduce tearing. For full screen, default to
      // PresentInterval.Default which will wait for the vertical retrace
      // period to prevent tearing.
      presentParams.PresentationInterval = PresentInterval.Immediate;
  

      // Create device and set some render states.
      // We require a pure hardware device. This can be done much nicer,
      // see the DirectX SDK and DXUtil classes, but this would be to
      // complex for this simple game IMO.
      /*
      device = new Device(0, DeviceType.Hardware,
        this,
        CreateFlags.HardwareVertexProcessing |
        //CreateFlags.MultiThreaded |
        CreateFlags.PureDevice, presentParams);
        */
      
        device = new Device(0, DeviceType.Hardware,
          this,
          CreateFlags.HardwareVertexProcessing |
          //CreateFlags.SoftwareVertexProcessing,
          //CreateFlags.MultiThreaded |
          CreateFlags.PureDevice,
          presentParams);
      
      // Copy used depth format in case we need it for creating
      // zBufferSurface in RenderToTexture.
      //backBufferDepthFormat = presentParams.AutoDepthStencilFormat;

      // It is very important for DirectX to dispose the objects in the
      // right order. We can't dispose the device first and then the
      // models and textures, DirectX will throw exceptions when disposing
      // meshes, shaders or textures. All the other events are important too.
      device.DeviceReset += new System.EventHandler(OnResetDevice);
      device.DeviceLost += new EventHandler(OnLostDevice);
      device.DeviceResizing += new CancelEventHandler(OnResizingDevice);
      device.Disposing += new EventHandler(OnDisposingDevice);

      // Initialize device settings for the first time.
      OnResetDevice(device, null);
    } 
    #endregion

    #region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.timer1 = new System.Windows.Forms.Timer(this.components);
      // 
      // timer1
      // 
      this.timer1.Interval = 20;
      this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
      // 
      // MainForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(872, 633);
      this.Name = "MainForm";
      this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
      this.Text = "Rinth Spires";
      this.Closed += new System.EventHandler(this.MainForm_Closed);

    }
    #endregion

    
    public static void EnableAlphaBlending()
    {
      /*
      device.SetTextureStageState(0, TextureStageStates.AlphaOperation, (int)TextureOperation.SelectArg1);
      device.SetTextureStageState(0, TextureStageStates.AlphaArgument1, (int)TextureArgument.TextureColor);
      */

      /*
      device.SetTextureStageState(0, TextureStageStates.ColorOperation, (int)TextureOperation.SelectArg1);
      device.SetTextureStageState(0, TextureStageStates.ColorArgument1, (int)TextureArgument.TextureColor);
      */
      device.SetTextureStageState(0, TextureStageStates.AlphaOperation, (int)TextureOperation.Modulate);
      device.SetTextureStageState(0, TextureStageStates.AlphaArgument1, (int)TextureArgument.Diffuse);
      device.SetTextureStageState(0, TextureStageStates.AlphaArgument2, (int)TextureArgument.TextureColor);
      
      device.RenderState.AlphaBlendEnable = true;
      device.RenderState.SourceBlend = Blend.SourceAlpha;
      device.RenderState.DestinationBlend = Blend.InvSourceAlpha;
    }

    

    #region Events
    protected override void OnClosed(EventArgs e)
    {
      if(fileout != null)
      {
        fileout.Close();
        fileout = null;
      }
      base.OnClosed (e);
      isNotClosed = false;
    }

    protected override void Dispose(bool disposing)
    {
      //--
      /*if (music != null)
        music.Dispose();
      music = null;
      Sound.Dispose();*/

      keyboardInput = null;
      mouseInput = null;

      base.Dispose(disposing);
    } 

    protected override void OnMouseMove(MouseEventArgs e)
    {
      mousePos = new Point(e.X, e.Y);
      base.OnMouseMove(e);
    } 

    protected bool showFps =
#if DEBUG
      true;
#else
			false;
#endif
    protected bool showGlow = true;
    protected override void OnKeyUp(KeyEventArgs e)
    {
      base.OnKeyUp(e);

      switch (e.KeyCode)
      {
        case Keys.F1:
          showFps = !showFps;
          e.Handled = true;
          break;

        case Keys.F2:
          showGlow = !showGlow;
          e.Handled = true;
          break;
      } 
    }

    public static string lastPressedKeys = "";
    public static int deletePressedKeys = 0;
    protected override void OnKeyPress(KeyPressEventArgs e)
    {
      base.OnKeyPress(e);
      if (e.Handled == false)
      {
        if (e.KeyChar >= 32 &&
          lastPressedKeys.Length < 20)
          lastPressedKeys += e.KeyChar;

        else if (e.KeyChar == (char)8)
          deletePressedKeys++;
      } 
    } 

    protected override void OnGotFocus(EventArgs e)
    {
      if (fullscreen)
        Cursor.Clip = resolutionRect;

      base.OnGotFocus(e);
    }

    protected override void OnLostFocus(EventArgs e)
    {
      if (fullscreen)
        Cursor.Clip = Rectangle.Empty;

      base.OnGotFocus(e);
    }

    #endregion

    public static int turn = 0;

    #region Update Loop
    public void UpdateLoop()
    {
      turn++;

      if(turn > 0)
        turn = 0;

      if(HandleDevice() == false) // Can we render?
      {
        //-- music.Pause();
        return;
      }

      // Update time and frame counters
      ElapsedTime.Update();

      // Update input
      keyboardInput.Update();
      mouseInput.Update();

      // if(music != null) music.Update();

      if(game != null && isActive)
        game.Process();
      
      if (device != null && device.Disposed == false && isDeviceLost == false && readyToDraw)
      {
        if(fullscreen)
          Cursor.Clip = resolutionRect;

        if(game != null && turn == 0)
          game.Render();
      } 
      
    }

    /// <summary>
    /// Handle device, makes sure everything is good and prepared for
    /// rendering. E.g. if the device was lost and we have to wait until
    /// we can restore it again, this method returns false and let the
    /// application know we can't render right now. It will also handle
    /// all restoring and building the projection matrix when required.
    /// </summary>
    /// <returns>True if we are good to render on the device, false otherwise.
    /// </returns>
    protected bool HandleDevice()
    {
      if (this.IsDisposed || this.Disposing)
      {
        bailout = true;
        return false;
      }

      bool isRenderingPaused = this.WindowState == FormWindowState.Minimized || (isActive == false && fullscreen);

      // If not active, wait for a short while to give other apps some time.
      if (isDeviceLost || isActive == false || isRenderingPaused)
        Thread.Sleep(20);

      if (isDeviceLost && isRenderingPaused == false && bailout == false) // Restore device if we are going active again!
      {
        isDeviceLost = false;

        int result;

        if (device.CheckCooperativeLevel(out result) == false)
        {
          if (result == (int)ResultCode.DeviceLost)
          {
            Thread.Sleep(80);
            isDeviceLost = true;
            return false;
          }

          try
          {
            OnLostDevice(null, EventArgs.Empty);
            this.FormBorderStyle = fullscreen ? FormBorderStyle.None : FormBorderStyle.Sizable;
            isDeviceLost = false;
            device.Reset(presentParams);
            //do we need this? OnResetDevice(null, EventArgs.Empty);
          }
          catch (DeviceLostException ex)
          {
            Console.WriteLine("!!!!! HandleDevice: " + ex.ToString());
            Thread.Sleep(100);
            isDeviceLost = true;
            return false;
          }
          catch
          {
            isDeviceLost = true;
            throw;
          }
        }
      }

      if (device == null || device.Disposed || isRenderingPaused || isDeviceLost)
        return false;

      if (promiseBuildProjectionMatrix)
      {
        promiseBuildProjectionMatrix = false;
        BuildProjectionMatrix();
      } 

      return true;
    } 
    #endregion

    #region Game Helper Functions
    public static void SetLightColor(int a_Light, Color a_Color)
    {
      device.Lights[a_Light].Ambient = a_Color;
      device.Lights[a_Light].Diffuse = a_Color;
      device.Lights[a_Light].Specular = a_Color;
    }
    #endregion

    #region Reset Events
    private void OnResetDevice(object sender, EventArgs e)
    {
      Console.WriteLine("----- OnResetDevice");

      if (device == null || device.Disposed)
        return;

      device.RenderState.ZBufferEnable = true;
      device.RenderState.CullMode = Cull.CounterClockwise;
      device.RenderState.Lighting = true;

      // Everything is solid
      device.RenderState.FillMode = FillMode.Solid;

      // Enable linear filtering
      //-- GraphicForm.EnableLinearTextureFiltering();

      // Leave world matrix to the standard identity
      worldMatrix = Matrix.Identity;
      // Create view and projection matrices (default stuff)
      device.Transform.View = ViewMatrix;

      BuildProjectionMatrix();

      // Create ambient light as material using our default colors.
      //--Material mat = new Material();
      //--device.Material = mat.D3DMaterial;

      Material mat = new Material();
      device.Material = mat.D3DMaterial;

      // Create and enable directional light
      device.Lights[0].Type = LightType.Directional;
      device.Lights[0].Enabled = true;

      SetLightColor(0, Color.White);

      device.Lights[0].Direction = new Vector3(0, -0.5f, 1);

      //--LightColor = Color.White;
      //--LensFlareColor = Color.White;
      //--SkyBackgroundColor = Color.White;
      //LightDir = DefaultLightDir;
      //--LightDir = -LensFlare.DefaultSunPos;

      // Normalize everything because x models are not normalized and
      // scaling the matrices would mess them up anyways :(
      // Well, this is still required for normal rendering without shaders,
      // will eat up maybe 1% performance, not so bad, only cpu anyway.
      // For shaders, this setting does not affect anything at all.
      device.RenderState.NormalizeNormals = true;

      // Accept ambient, diffuse and specular color from material
      device.RenderState.AmbientMaterialSource = ColorSource.Material;
      device.RenderState.DiffuseMaterialSource = ColorSource.Material;
      device.RenderState.SpecularMaterialSource = ColorSource.Material;
      device.RenderState.SpecularEnable = true;

      //--remBackSufferSurface = device.GetBackBuffer(0, 0, BackBufferType.Mono);
      //--remDepthStencilSurface = device.DepthStencilSurface;

      // Call all our IGraphicObjects and reset them too
      if(game != null)
        game.OnResetDevice();
      
    }

    private void OnLostDevice(object sender, EventArgs e)
    {
      Console.WriteLine("----- OnLostDevice");

      try
      {
        // Oh oh, device is lost, we have to restore it in HandleApplication()
        isDeviceLost = true;

        // Call all our IGraphicObjects and reset them too
        if(game != null)
          game.OnLostDevice();
      } 
      catch (Exception ex)
      {
        Console.WriteLine("!!!!! OnLostDevice: " + ex.ToString());
        //-- Console.WriteLine("Failed to release device objects in OnLostDevice: " + ex.ToString());
      }
    } 

    private void OnDisposingDevice(object sender, EventArgs e)
    {
      Console.WriteLine("----- OnDisposingDevice");

      if (device == null || device.Disposed)
        return;

      try
      {
        if(game != null)
          game.OnDisposingDevice();
      } 
      catch (Exception ex)
      {
        Console.WriteLine("!!!!! OnDisposingDevice: " + ex.ToString());
        //-- Console.WriteLine("Failed to dispose device objects: " + ex.ToString());
      } 
      finally
      {
        device = null;
        bailout = true;
      }
    }

    
    private void OnResizingDevice(object sender, CancelEventArgs e)
    {
      Console.WriteLine("----- OnResizingDevice");

      if (device == null)
        return;

      try
      {
        // If the device is lost, the app is minimized or not acitve, then do nothing
        if (device.CheckCooperativeLevel() == false || this.WindowState == FormWindowState.Minimized || this.isActive == false)
        {
          e.Cancel = true;
        }

        // Remember we are resizing
        //currentlyResizing = true;

        if (WindowState != FormWindowState.Minimized)
        {
          // Minimum size is 320x200
          if (this.Size.Width < 320 ||
            this.Size.Height < 200)
            this.Size = new Size(320, 200);

          this.Size = new Size(this.Size.Width, (int)(this.Size.Width / 1.4f));
          
          promiseBuildProjectionMatrix = true;
        }
      }
      catch (Exception ex)
      {
        Console.WriteLine("!!!!! OnResizingDevice: " + ex.ToString());
        //--Console.WriteLine("OnDeviceResizing failed: " + ex.ToString());
      }
    }

    protected override void OnActivated(EventArgs e)
    {
      Console.WriteLine("----- OnActivated");

      isActive = true;
      if (this.WindowState == FormWindowState.Minimized)
        this.WindowState = FormWindowState.Normal;
    }

    protected override void OnDeactivate(EventArgs e)
    {
      Console.WriteLine("----- OnDeactivate");
      isActive = false;
    } 
    #endregion

    #region Special Graphics Things
    public void BuildProjectionMatrix()
    {
      float aspectRatio = 1.0f;
      if (this.Height != 0)
        aspectRatio = (float)this.Width / (float)this.Height;
      
      ProjectionMatrix = Matrix.PerspectiveFovLH(fieldOfView, aspectRatio, nearPlane, farPlane);
      device.Transform.View = ViewMatrix;
    } 

    #endregion

    private void timer1_Tick(object sender, System.EventArgs e)
    {
      
      if(game != null)
      {
        /*
        ((AnimatedPawn)GameClass.pawns[0]).currentFrame++;
        if(((AnimatedPawn)GameClass.pawns[0]).currentFrame > (int)((AnimatedPawn)GameClass.pawns[0]).lastframe["walking"])
          ((AnimatedPawn)GameClass.pawns[0]).currentFrame = 0;
          */
      }
      
    }

    private void MainForm_Closed(object sender, System.EventArgs e)
    {
      Application.Exit();
    }
	}

  public class NativeMethods
  {
    [StructLayout(LayoutKind.Sequential)]
      public struct Message
    {
      public IntPtr hWnd;
      public uint msg;
      public IntPtr wParam;
      public IntPtr lParam;
      public uint time;
      public System.Drawing.Point p;
    }

    [System.Security.SuppressUnmanagedCodeSecurity] // We won't use this maliciously
    [DllImport("User32.dll", CharSet=CharSet.Auto)]
    public static extern bool PeekMessage(out Message msg, IntPtr hWnd, uint messageFilterMin, uint messageFilterMax, uint flags);
  }
}
