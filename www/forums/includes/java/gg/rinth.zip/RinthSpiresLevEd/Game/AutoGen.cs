#region Using
using System;
using System.Collections;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.Threading;
using System.ComponentModel;
using System.Data;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using Microsoft.DirectX.DirectInput;
#endregion

namespace RinthSpires
{
  class AutoGen
  {
    public static void LoadModels()
    {
      //AUTOGEN Models
      GameClass.modelSource.Add("Cube",   new Model("mdl_cube.x"));
      GameClass.modelSource.Add("Rinth",   new Model("mdl_rinth.x"));
      GameClass.modelSource.Add("Barrel",  new Model("mdl_barrel.x"));
      GameClass.modelSource.Add("Crate",   new Model("mdl_crate.x"));
      GameClass.modelSource.Add("Cliffs",   new Model("mdl_cliffs.x"));
      GameClass.modelSource.Add("Brick",   new Model("mdl_brick.x"));
      GameClass.modelSource.Add("Ladder",   new Model("mdl_ladder.x"));
      GameClass.modelSource.Add("Frame",   new Model("mdl_frame.x"));
      GameClass.modelSource.Add("Gate",   new Model("mdl_gate.x"));
      GameClass.modelSource.Add("Bomb",   new Model("mdl_bomb.x"));
      GameClass.modelSource.Add("Water",   new Model("mdl_water.x"));
      GameClass.modelSource.Add("Horizon",   new Model("mdl_horizon.x"));
      GameClass.modelSource.Add("Column",   new Model("mdl_column.x"));
      GameClass.modelSource.Add("Palm",   new Model("mdl_palm.x"));
      GameClass.modelSource.Add("Lift",   new Model("mdl_lift.x"));
      GameClass.modelSource.Add("Gift",   new Model("mdl_gift.x"));
      GameClass.modelSource.Add("Sign",   new Model("mdl_sign.x"));
      GameClass.modelSource.Add("Grass",   new Model("mdl_grass.x"));
      GameClass.modelSource.Add("Ledge",   new Model("mdl_ledge.x"));
      GameClass.modelSource.Add("Bridge",   new Model("mdl_bridge.x"));
      GameClass.modelSource.Add("Switch",   new Model("mdl_switch.x"));
      GameClass.modelSource.Add("Spotlight",   new Model("mdl_spotlight.x"));
      GameClass.modelSource.Add("Tite1",   new Model("mdl_tite1.x"));
      GameClass.modelSource.Add("Tite2",   new Model("mdl_tite2.x"));
      GameClass.modelSource.Add("Mist",   new Model("mdl_mist.x"));
      GameClass.modelSource.Add("City",   new Model("mdl_city.x"));
      GameClass.modelSource.Add("Totem",   new Model("mdl_totem.x"));
      GameClass.modelSource.Add("Patch",   new Model("mdl_patch.x"));
      GameClass.modelSource.Add("Falls",   new Model("mdl_falls.x"));
      GameClass.modelSource.Add("Stem",   new Model("mdl_stem.x"));
      GameClass.modelSource.Add("Shrub",   new Model("mdl_shrub.x"));
      GameClass.modelSource.Add("Drone",   new Model("mdl_drone.x"));
      GameClass.modelSource.Add("Windmill",   new Model("mdl_windmill.x"));
      GameClass.modelSource.Add("Lode",   new Model("mdl_lode.x"));
      GameClass.modelSource.Add("Tree",   new Model("mdl_tree.x"));
      GameClass.modelSource.Add("Trunk",   new Model("mdl_trunk.x"));
      GameClass.modelSource.Add("Sky_Rainbow",   new Model("sky_rainbow.x"));
      GameClass.modelSource.Add("Sky_Abyss",   new Model("sky_abyss.x"));
      GameClass.modelSource.Add("Sky_Dusk",   new Model("sky_dusk.x"));
      GameClass.modelSource.Add("Sky_Trees",   new Model("sky_trees.x"));
      GameClass.modelSource.Add("Firefly",   new Model("mdl_firefly.x"));
      GameClass.modelSource.Add("Branch",   new Model("mdl_branch.x"));
      GameClass.modelSource.Add("Limb",   new Model("mdl_limb.x"));
      GameClass.modelSource.Add("TwigL",   new Model("mdl_twigl.x"));
      GameClass.modelSource.Add("TwigR",   new Model("mdl_twigr.x"));
      GameClass.modelSource.Add("Log",   new Model("mdl_log.x"));
      GameClass.modelSource.Add("LogRest",   new Model("mdl_logrest.x"));
      GameClass.modelSource.Add("Rock",   new Model("mdl_rock.x"));
      GameClass.modelSource.Add("Vent",   new Model("mdl_vent.x"));
      GameClass.modelSource.Add("VentRest",   new Model("mdl_ventrest.x"));
      GameClass.modelSource.Add("Outlet",   new Model("mdl_outlet.x"));
      GameClass.modelSource.Add("Bolt",   new Model("mdl_bolt.x"));
      GameClass.modelSource.Add("Wetstone",   new Model("mdl_wetstone.x"));
      GameClass.modelSource.Add("WetstoneRest",   new Model("mdl_wetstonerest.x"));
      GameClass.modelSource.Add("Mountain",   new Model("mdl_mountain.x"));
      GameClass.modelSource.Add("Mountains",   new Model("mdl_mountains.x"));
      GameClass.modelSource.Add("Angry1",   new Model("mdl_angry1.x"));
      GameClass.modelSource.Add("Angry2",   new Model("mdl_angry2.x"));
      //AUTOGEN Models

      //backgroundTexture = new Texture("SpaceSkyCubeMap.dds");

      /*
      AnimatedPawn hero = new AnimatedPawn();

      hero.modelNames.Add("head");
      hero.modelNames.Add("torso");
      hero.modelNames.Add("leftplate");
      hero.modelNames.Add("leftarm");
      hero.modelNames.Add("leftfoot");
      hero.modelNames.Add("rightplate");
      hero.modelNames.Add("rightarm");
      hero.modelNames.Add("rightfoot");
      hero.modelNames.Add("sword");
      hero.modelNames.Add("shield");
      hero.modelNames.Add("cape");

      hero.AddAnimation("walking", "champion.anim");

      //pawns.Add(hero.Clone());
      */

      /*
      pawns.Add(hero);
      pawns.Add(new Pawn());
      pawns.Add(new ExtendablePawn(Matrix.RotationY((3 * (float)Math.PI) / 2), "brick", 1, 1, 3, 16, 16));
      pawns.Add(new ExtendablePawn(Matrix.Identity, "brick", 3, 1, 1, 16, 16));
      pawns.Add(new ExtendablePawn(Matrix.Identity, "tile", 3, 1, 3, 16, 16));
      */

      
    }
  }
}