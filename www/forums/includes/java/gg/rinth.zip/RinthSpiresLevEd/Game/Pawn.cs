#region Using
using System;
using System.Collections;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.Threading;
using System.ComponentModel;
using System.Data;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using DirectXMaterial = Microsoft.DirectX.Direct3D.Material;
#endregion

namespace RinthSpires
{
  public class Pawn : ICloneable
  {
    public static float GetRads(float degrees){return degrees * ((float)Math.PI / 180);}

    public string baseModel = "cube";
    public Matrix matrix = Matrix.Identity;
    public float height = 1;
    public float width = 1;
    public float baseOpacity = 1.0f;

    public int rinth_rotate = 0;

    public ArrayList modelNames = new ArrayList();
    public SortedList animations = new SortedList();
    public SortedList lastFrame = new SortedList();

    public string className = "";

    public string currentAnimation = "";  
    public int currentFrame = 0;   

    //RINTH
    public virtual bool Blocks(string pawnName)
    {
      return false;
    }

    //RINTH
    public virtual bool Supports(string pawnName)
    {
      return false;
    }
    
    //RINTH
    public virtual void Overlaps(string pawnName, ref string obj1, ref string obj2)
    {
      obj1 = "base";
      obj2 = "base";
    }

    // Processes the pawn's current task
    // Returns:
    //   "die" Pawn should be destroyed
    //   "tx-" Pawn should be moved left on the tower
    //   "tx+" Pawn should be moved right on the tower
    //   "ty-" Pawn should be moved up on the tower
    //   "ty+" Pawn should be moved down on the tower
    public virtual string Process(float delta)
    {
      return "";
    }

    public Pawn()
    {
    }

    public Pawn(string sBaseModel)
    {
      baseModel = sBaseModel;
    }

    public Pawn(Matrix mMatrix, string sBaseModel)
    {
      matrix = mMatrix;
      baseModel = sBaseModel;
    }

    public Pawn(ArrayList alModelNames, SortedList slAnimations, SortedList slLastFrame, Matrix mMatrix, string sBaseModel, string sCurrentAnimation, int iCurrentFrame, string sClassName, float fBaseOpacity, float iWidth, float iHeight)
    {
      modelNames = alModelNames;
      animations = slAnimations;
      lastFrame = slLastFrame;
      matrix = mMatrix;
      baseModel = sBaseModel;
      currentAnimation = sCurrentAnimation;
      currentFrame = iCurrentFrame;
      className = sClassName;  
      baseOpacity = fBaseOpacity;

      width = iWidth;
      height = iHeight;
    }



    //      1  *           1  *       1  *
    // pawn ---< animation ---< frame ---< framemember

    

    public object Clone()
    {
      return new Pawn((ArrayList)this.modelNames.Clone(), (SortedList)this.animations.Clone(), (SortedList)this.lastFrame.Clone(), this.matrix, this.baseModel, this.currentAnimation, this.currentFrame, this.className, this.baseOpacity, this.width, this.height);
    }

    public void Render(Matrix overmatrix)
    {  
      //MainForm.DirectXDevice.SetTextureStageState(0, TextureStageStates.TextureTransform, (int)TextureTransform.Count2 ); 
      //MainForm.DirectXDevice.Transform.Texture0 = Matrix.Scaling(5.0f, 1.0f, 1.0f);         

      if(animations.Count < 1 || currentAnimation == "")
      {
        if(baseModel == "")
          return;

        if(baseOpacity != 1)
          ((Model)GameClass.modelSource[baseModel]).RenderOpacity(matrix * overmatrix, baseOpacity);
        else
          ((Model)GameClass.modelSource[baseModel]).Render(matrix * overmatrix);
      }
      else
      {
        foreach(FrameMember thing in (ArrayList)((ArrayList)animations[currentAnimation])[currentFrame])
        {
          if(thing.opacity != 1 || baseOpacity != 1)
            ((Model)GameClass.modelSource[(string)modelNames[thing.identifier]]).RenderOpacity(thing.matrix * matrix * overmatrix, thing.opacity * baseOpacity); 
          else
            ((Model)GameClass.modelSource[(string)modelNames[thing.identifier]]).Render(thing.matrix * matrix * overmatrix); 
        }
      }

      //MainForm.DirectXDevice.SetTextureStageState( 0, TextureStageStates.TextureTransform, (int)TextureTransform.Disable ); 
    }   

    public void Render(Matrix overmatrix, Color [] lighting)
    {  
      //MainForm.DirectXDevice.SetTextureStageState(0, TextureStageStates.TextureTransform, (int)TextureTransform.Count2 ); 
      //MainForm.DirectXDevice.Transform.Texture0 = Matrix.Scaling(5.0f, 1.0f, 1.0f);         

      if(animations.Count < 1)
      {
        if(baseModel == "")
          return;

        if(baseOpacity != 1)
          ((Model)GameClass.modelSource[baseModel]).RenderOpacity(matrix * overmatrix, baseOpacity, lighting);
        else
          ((Model)GameClass.modelSource[baseModel]).Render(matrix * overmatrix, lighting);
      }
      else
      {
        foreach(FrameMember thing in (ArrayList)((ArrayList)animations[currentAnimation])[currentFrame])
        {
          if(thing.opacity != 1 || baseOpacity != 1)
            ((Model)GameClass.modelSource[(string)modelNames[thing.identifier]]).RenderOpacity(thing.matrix * matrix * overmatrix, thing.opacity * baseOpacity, lighting); 
          else
            ((Model)GameClass.modelSource[(string)modelNames[thing.identifier]]).Render(thing.matrix * matrix * overmatrix, lighting); 
        }
      }

      //MainForm.DirectXDevice.SetTextureStageState( 0, TextureStageStates.TextureTransform, (int)TextureTransform.Disable ); 
    }   

    public void AddAnimation(string label, string filename)
    {
      StreamReader reader = new StreamReader(new FileStream(filename, FileMode.Open, FileAccess.Read)); 
      
      ArrayList animation = new ArrayList();
      ArrayList frame = new ArrayList();

      string line = "";
      string state = "outside";

      int last = -1;

      try
      {
        while(reader.Peek() >= 0)
        {
          line = reader.ReadLine();

          if(line != "" && line != "." && line != "!") // garbage lines
          {
            if(line == "#" && state == "outside")
            {
              frame.Clear();
              state = "frame";
            }
            else if(line == "#" && state == "frame")
            {
              animation.Add(frame.Clone());
              state = "outside";
              last++;
            }
            else if(line == "$" && state == "frame")
            {
              int id = Convert.ToInt32(reader.ReadLine());

              string fm_label = reader.ReadLine(); // FrameMember Label

              float xa = Convert.ToSingle(reader.ReadLine());
              float ya = Convert.ToSingle(reader.ReadLine());
              float za = Convert.ToSingle(reader.ReadLine());

              float xo = Convert.ToSingle(reader.ReadLine());
              float yo = Convert.ToSingle(reader.ReadLine());
              float zo = Convert.ToSingle(reader.ReadLine());

              float xs = Convert.ToSingle(reader.ReadLine());
              float ys = Convert.ToSingle(reader.ReadLine());
              float zs = Convert.ToSingle(reader.ReadLine());

              int o = Convert.ToInt32(reader.ReadLine());

              Matrix t = Matrix.Translation(new Vector3(xo, yo, -zo));
              
              Matrix r = Matrix.RotationZ(GetRads(za)) *
                Matrix.RotationY(GetRads(-ya)) *
                Matrix.RotationX(GetRads(-xa));

              frame.Add(new FrameMember(id, r * t, (float)(o / 100)));

              reader.ReadLine(); // $
            }    
          }
        }

        lastFrame.Add(label, last);
        animations.Add(label, animation.Clone());
        

        //if(currentAnimation == "")
        //  currentAnimation = label;

        Console.WriteLine("----- '" + label + "' (from " + filename + ") loaded!");        
      }
      catch(Exception ex)
      {
        Console.WriteLine("!!!!! Failed to add animation" + ex.ToString());
      }

      reader.Close(); 
    }
  }

  public class FrameMember : ICloneable
  {
    public Matrix matrix = Matrix.Identity;
    public int identifier = 0;
    public float opacity = 100;

    public FrameMember()
    {
    }

    public FrameMember(int id)
    {
      identifier = id;
    }

    public FrameMember(int id, Matrix m, float o)
    {
      identifier = id;
      matrix = m;
      opacity = o;
    }

    public object Clone()
    {
      return new FrameMember(this.identifier, this.matrix, this.opacity);
    }
  }
}
